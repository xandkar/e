# Execution V5.0x.1 — 0x-backed, provider-neutral quote service

**Scope:** Runnable Rust prototype for **one exact-input, same-chain ERC-20 swap**,
quoting through 0x Swap API v2 (`AllowanceHolder`), using Kafka + PostgreSQL,
with explicit authorization and a Fireblocks Egress handoff. This is **not** a
complete lending-account migration engine or an audited production executor.

The 0x integration supplies routing, swap pricing, a slippage floor, fees,
validation issues, and executable swap calldata. We deliberately do not
implement custom DEX routing, pricing, or transaction assembly for swaps.

## Architecture

```
Kafka: execution.quote.requests.v1
    ↓
OfferProvider (trait) → ZeroExProvider (0x /swap/allowance-holder/quote)
    ↓
ExecutionOffer (route + economics + execution binding + readiness)
    ↓
PostgreSQL (offer, expiry, request-id dedupe, outbox)
    ↓
Kafka: execution.quote.results.v1
    ↓
Strategy: inspect quote; authorize offer-id under limits
    ↓
Kafka: execution.commands.v1
    ↓
Authorize once (PostgreSQL transaction / row lock)
    ↓
Kafka: execution.egress.commands.v1
    ↓
Existing Egress (revalidate, sign via Fireblocks, confirm + reconcile)
```

Additional result topic: `execution.authorization.results.v1`.

The Kafka body is `Envelope<T>` with version 1 and snake_case Rust serde
names. Example request envelopes: `tests/fixtures/quote_request.json` and
`tests/fixtures/execute_request.json`. Replace placeholders and timestamps.

## Run locally

Requires Rust/Cargo, PostgreSQL, Kafka broker, and a 0x API key.

1. Create the database and apply `migrations/001_initial.sql` with `psql`.
2. Create Kafka topics listed above, and configure broker ACLs.
3. Export variables from `.env.example` (do not commit API keys).
4. Verify the chain and AllowanceHolder address against the official 0x docs.
5. Run `cargo test` and `cargo run`.
6. Publish a quote request envelope from the fixture with a **real taker owned
   by the configured Fireblocks vault**. Watch `execution.quote.results.v1`.
7. If `readiness=approval_required`, use your custody Egress to approve only the
   response's `approval.spender` for the exact sell amount, confirm it, and
   send a **new quote request with a new request_id**. Do not execute the old
   quote. Some ERC-20 contracts require zeroing an existing allowance first.
8. When `readiness=ready`, submit an authorization referring to `offer.id`.
   Only the first accepted authorization can consume it.

The application does not create Kafka topics, seed token addresses, or execute
Fireblocks transactions. It uses the existing Egress component, which should
consume `execution.egress.commands.v1` and report actual execution status.

## Configuration

* `ZEROX_API_KEY`: private API key.
* `ZEROX_CHAIN_ID`: **only permitted chain** for this service instance.
* `ZEROX_ALLOWANCE_HOLDER`: allowlisted AllowanceHolder deployment (ERC-20
  swaps must target this address); use a separate instance/config per chain.
* `DATABASE_URL`, `KAFKA_BROKERS`, optional `RUST_LOG`.

This version intentionally uses `/swap/allowance-holder/quote`, **not**
`/swap/permit2/quote`: Permit2 can require a separate EIP-712 signature flow.
Never approve Settler. Never derive approval spender from `transaction.to`
unless independently verified against the approved deployment.

## Safety and economic semantics

* Integer base units everywhere. No floats; 256-bit range validation.
* 0x's `buyAmount` is treated as net quoted swap proceeds; 0x trading fees
  represented separately are marked included so consumers do not double count.
* `minBuyAmount` is the 0x on-chain quote floor, not an independently imposed
  higher floor. Authorization rejects any requested minimum **above** it.
* `totalNetworkFee` is an indicative network estimate, not a hard cap; the
  strategy authorizes a separate maximum. Existing Egress must enforce gas
  limit × gas price and block on stale or unexecutable transactions.
* `expires_at` is a **local 25-second maximum age**, not a guarantee that an
  RFQ, pool liquidity, market price, or custody approval stays valid that long.
* `issues.balance` or `simulationIncomplete` makes a quote unavailable. Missing
  allowance yields a non-executable offer and a precise approval request.
* The full 0x calldata and target are digest-bound to the offer. Egress must
  verify it is the *actual authorized quote* from trusted PostgreSQL, not only
  recompute a digest from an untrusted Kafka payload.
* Egress must independently validate chain, source wallet ↔ Fireblocks vault,
  token and contract allowlists, approval and balance, simulation, current gas,
  min output enforced by calldata, deadline, and limits **immediately before
  submitting**. Wait for receipts; reconcile actual sell/buy balance changes.
* Store only essential quote data and protect execution events with ACLs:
  they contain financially sensitive quantities and authorized calldata.
* Deduplicate Kafka consumers by `message_id`/`execution_id`; fireblocks
  `externalTxId` is stable (`swap:<execution_id>:0`). Do not blindly repeat a
  submission after a network timeout; query Fireblocks by externalTxId.
* Outbox is **at least once**; downstream execution MUST remain idempotent.
* Quote API errors are returned as an `unavailable` event. Retry with a new
  `request_id`; production should add backoff, metrics, DLQ/poison-message
  handling, and quote latency budgets.

## How to replace 0x

Implement `OfferProvider::offers(&SwapIntent) -> Result<Vec<ExecutionOffer>>`
and register it in `ExecutionService.providers`. The provider must produce a
common `ExecutionOffer`, with a whitelisted execution target, source token,
amount, minimum output, costs, provenance, expiry, and digest-bound EVM call.
A future `QuoteBatch` can collect more than one candidate; **this prototype
emits the first successful offer only**.

`egress::to_fireblocks_request` is a pure Fireblocks request builder, supplied
with independently verified vault/taker mapping, target address, gas estimate,
current base fee, tip, and configured native base asset ID. It constructs a
`CONTRACT_CALL` request body using `extraParameters.contractCallData` and
`externalTxId`, but deliberately does **not** sign or send it. Hook the function
into the existing Egress after revalidation and custody policy evaluation.

## Lending-pool reallocation integration

0x is a **swap venue**, not a general-purpose lending-migration planner:

```
Aave Withdraw (native protocol adapter)
      ↓ confirmed wallet asset balance
0x Swap       (this provider; requote after withdrawal)
      ↓ confirmed output asset balance
Aave Supply   (native protocol adapter)
```

There is no single atomic guarantee across these operations. If withdrawal
succeeds but the swap or supply fails, report and recover the partial
execution. Do not pre-authorize an unbounded future swap based solely on a
pre-withdrawal quote. Full position planning and atomic migrations would use
separate route providers (or later Enso/Portals-based adapters).

## Known limitations of V5.0x.1

- No Fireblocks transport/authentication, transaction receipt watcher, or
  integration with on-chain wallet state is bundled; your existing Egress does
  these. The Fireblocks request builder is intentionally **not a signer**.
- No venue-level quote aggregation beyond the routes 0x selects internally.
- No native-token swaps, Permit2, cross-chain routes, partially-filled orders,
  sponsored gas, or composite lending recipes.
- No end-to-end simulation by this service; rely on 0x validation and Egress
  pre-submission simulation. Use Tenderly or native RPC independently later.
- No guaranteed execution/quote fill; RPC/custody latency can exceed quote
  validity. Post-authorization Egress must fail closed if expired.
- Kafka input poison messages currently stop the worker; deploy with a
  supervisor and add DLQ recovery before production use.

## Primary documentation

- https://docs.0x.org/docs/introduction/quickstart/swap-tokens-with-0x-swap-api
- https://docs.0x.org/docs/upgrading/upgrading-to-swap-v2
- https://docs.0x.org/docs/core-concepts/contracts
- https://fireblocks.readme.io/reference/createtransaction
