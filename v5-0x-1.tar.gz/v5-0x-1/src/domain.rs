use anyhow::{bail, ensure, Context, Result};
use chrono::{DateTime, Utc};
use num_bigint::BigUint;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use uuid::Uuid;

pub fn address(s: &str) -> Result<String> {
    ensure!(s.len() == 42 && s.starts_with("0x") && s.as_bytes()[2..].iter().all(|c| c.is_ascii_hexdigit()), "invalid EVM address");
    Ok(s.to_ascii_lowercase())
}

pub fn uint256(s: &str) -> Result<BigUint> {
    ensure!(!s.is_empty() && s.bytes().all(|c| c.is_ascii_digit()), "expected unsigned decimal integer");
    let value = BigUint::parse_bytes(s.as_bytes(), 10).context("invalid integer")?;
    ensure!(value.bits() <= 256, "value overflows uint256");
    Ok(value)
}

pub fn positive_uint256(s: &str) -> Result<BigUint> {
    let n = uint256(s)?;
    ensure!(n > BigUint::from(0u8), "amount must be positive");
    Ok(n)
}

pub fn evm_data(s: &str) -> Result<()> {
    ensure!(s.len() >= 10 && s.len() <= 262_146 && s.len() % 2 == 0 && s.starts_with("0x") && s.as_bytes()[2..].iter().all(|c| c.is_ascii_hexdigit()), "invalid EVM calldata");
    Ok(())
}

pub fn sha256_hex(bytes: &[u8]) -> String {
    format!("0x{}", hex::encode(Sha256::digest(bytes)))
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SwapIntent {
    pub id: Uuid,
    pub strategy_id: String,
    pub chain_id: u64,
    pub vault_id: String,        // existing Fireblocks vault-account identifier
    pub taker: String,           // wallet controlled by that vault; verify in Egress
    pub sell_token: String,      // ERC-20; native tokens intentionally excluded
    pub buy_token: String,
    pub sell_amount: String,     // integer base units, never floating point
    pub slippage_bps: u16,
}
impl SwapIntent {
    pub fn validate(&self) -> Result<()> {
        ensure!(!self.strategy_id.is_empty() && !self.vault_id.is_empty(), "missing identity");
        ensure!(self.chain_id != 0, "invalid chain");
        ensure!(self.slippage_bps <= 1_000, "slippage above service cap of 1000 bps");
        ensure!(address(&self.sell_token)? != address(&self.buy_token)?, "identical tokens");
        for a in [&self.taker, &self.sell_token, &self.buy_token] { address(a)?; }
        positive_uint256(&self.sell_amount)?;
        // Native 0x token pseudo-address: unsupported in this initial adapter.
        const NATIVE: &str = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
        ensure!(self.sell_token.to_ascii_lowercase() != NATIVE && self.buy_token.to_ascii_lowercase() != NATIVE, "native tokens unsupported");
        Ok(())
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct QuoteRequested { pub request_id: Uuid, pub intent: SwapIntent }

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Envelope<T> {
    pub version: u16,
    pub message_id: Uuid,
    pub correlation_id: Uuid,
    pub created_at: DateTime<Utc>,
    pub payload: T,
}
impl<T> Envelope<T> {
    pub fn new(correlation_id: Uuid, payload: T) -> Self {
        Self { version: 1, message_id: Uuid::new_v4(), correlation_id, created_at: Utc::now(), payload }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct EvmCall {
    pub to: String,
    pub data: String,
    pub value_wei: String,
    pub estimated_gas: String,
    pub quoted_gas_price_wei: String,
}
impl EvmCall {
    pub fn validate(&self) -> Result<()> {
        address(&self.to)?;
        evm_data(&self.data)?;
        uint256(&self.value_wei)?;
        positive_uint256(&self.estimated_gas)?;
        positive_uint256(&self.quoted_gas_price_wei)?;
        Ok(())
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ApprovalRequirement {
    pub token: String,
    pub spender: String,
    pub amount: String,
    pub call: EvmCall, // no implicit approval; Egress handles separately
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum Readiness { Ready, ApprovalRequired }

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SwapRoute {
    pub provider: String,
    pub sell_token: String,
    pub buy_token: String,
    pub sell_amount: String,
    pub taker: String,
    pub chain_id: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FeeComponent {
    pub kind: String,
    pub token: String,
    pub amount: String,
    pub included_in_buy_amount: bool,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct EconomicQuote {
    pub expected_buy_amount: String,
    pub minimum_buy_amount: String,
    pub estimated_network_fee_wei: String,
    pub fees: Vec<FeeComponent>,
    pub estimation_source: String,
    pub source_block_number: Option<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ExecutionBinding {
    pub provider: String,
    pub method: String,
    pub swap: EvmCall,
    pub approval: Option<ApprovalRequirement>,
    pub payload_digest: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ExecutionOffer {
    pub id: Uuid,
    pub intent_id: Uuid,
    pub strategy_id: String,
    pub vault_id: String,
    pub readiness: Readiness,
    pub route: SwapRoute,
    pub quote: EconomicQuote,
    pub binding: ExecutionBinding,
    pub issued_at: DateTime<Utc>,
    // Local maximum age, NOT a 0x promise of quote validity.
    pub expires_at: DateTime<Utc>,
}
impl ExecutionOffer {
    pub fn validate_binding(&self) -> Result<()> {
        self.binding.swap.validate()?;
        let actual = sha256_hex(serde_json::to_vec(&self.binding.swap)?.as_slice());
        ensure!(actual == self.binding.payload_digest, "quote binding digest mismatch");
        ensure!(self.binding.provider == self.route.provider, "provider mismatch");
        Ok(())
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum QuoteResult {
    Offered { request_id: Uuid, offer: ExecutionOffer },
    Unavailable { request_id: Uuid, code: String, reason: String },
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ExecuteRequested {
    pub execution_id: Uuid,
    pub offer_id: Uuid,
    pub strategy_id: String,
    pub min_buy_amount: String,
    pub max_network_fee_wei: String,
    pub deadline: DateTime<Utc>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum AuthorizationResult {
    Accepted { execution_id: Uuid, offer_id: Uuid },
    Rejected { execution_id: Uuid, reason: String },
}

// Provider-neutral Egress command, not a direct Fireblocks API request.
// The existing Egress translates it to CONTRACT_CALL and enforces controls.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ContractCallCommand {
    pub execution_id: Uuid,
    pub offer_id: Uuid,
    pub chain_id: u64,
    pub vault_id: String,
    pub taker: String,
    pub call: EvmCall,
    pub binding_digest: String,
    pub min_buy_amount: String,
    pub buy_token: String,
    pub sell_token: String,
    pub sell_amount: String,
    pub max_network_fee_wei: String,
    pub deadline: DateTime<Utc>,
    pub fireblocks_external_tx_id: String,
}

pub fn erc20_approval(token: &str, spender: &str, amount: &str) -> Result<EvmCall> {
    let spender = address(spender)?;
    let amount = positive_uint256(amount)?;
    let address_word = format!("{:0>64}", &spender[2..]);
    let amount_word = format!("{:0>64}", amount.to_str_radix(16));
    if amount_word.len() != 64 { bail!("invalid encoded uint256") }
    Ok(EvmCall {
        to: address(token)?,
        data: format!("0x095ea7b3{address_word}{amount_word}"),
        value_wei: "0".into(),
        estimated_gas: "65000".into(), // indicative, must be reestimated by Egress
        quoted_gas_price_wei: "1".into(), // placeholder, not an approved fee cap
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn encodes_exact_erc20_approval() {
        let token = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48";
        let spender = "0x0000000000001ff3684f28c67538d4d072c22734";
        let approval = erc20_approval(token, spender, "1000000").unwrap();
        assert_eq!(approval.data.len(), 138);
        assert!(approval.data.ends_with("00000000000000000000000000000000000000000000000000000000000f4240"));
    }
    #[test]
    fn rejects_bad_amounts() {
        assert!(uint256("1.5").is_err());
        assert!(positive_uint256("0").is_err());
        assert!(uint256(&"9".repeat(100)).is_err());
    }
}
