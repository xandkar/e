use crate::{domain::*, store::PgStore, zeroex::OfferProvider};
use anyhow::Result;
use std::sync::Arc;

pub struct ExecutionService {
    pub providers: Vec<Arc<dyn OfferProvider>>,
    pub store: PgStore,
}

impl ExecutionService {
    pub async fn quote(&self, request: QuoteRequested) -> Result<QuoteResult> {
        let request_digest = sha256_hex(&serde_json::to_vec(&request)?);
        let response = if let Err(error) = request.intent.validate() {
            QuoteResult::Unavailable {
                request_id: request.request_id,
                code: "INVALID_INTENT".into(), reason: error.to_string(),
            }
        } else {
            let mut offers = Vec::new();
            let mut failures = Vec::new();
            for provider in &self.providers {
                match provider.offers(&request.intent).await {
                    Ok(mut candidates) => offers.append(&mut candidates),
                    Err(e) => failures.push(format!("{}: {}", provider.name(), e)),
                }
            }
            // V5.0x.1 has one provider and one route. V6 can return a batch
            // with multiple provider offers without changing provider traits.
            match offers.into_iter().next() {
                Some(offer) => QuoteResult::Offered { request_id: request.request_id, offer },
                None => QuoteResult::Unavailable {
                    request_id: request.request_id,
                    code: "NO_QUOTE".into(), reason: failures.join("; "),
                },
            }
        };
        self.store.save_quote(request.request_id, request.intent.id, &request_digest, &response).await?;
        Ok(response)
    }
}
