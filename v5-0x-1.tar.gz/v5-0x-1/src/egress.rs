//! Pure Fireblocks request adapter. It does NOT submit transactions.
//! The existing Egress service must independently authenticate authorization,
//! verify vault ownership, current balances, allowance, 0x calldata constraints,
//! RPC simulation, quote freshness, and custody/chain status.
use crate::domain::*;
use anyhow::{ensure, Result};
use num_bigint::BigUint;
use serde_json::{json, Value};
use chrono::Utc;

/// Represent integer wei as an exact numeric Gwei string, with <=9 decimals.
fn wei_as_gwei(wei: &BigUint) -> String {
    let billion = BigUint::from(1_000_000_000u64);
    let units = wei / &billion;
    let decimals = wei % &billion;
    if decimals == BigUint::from(0u8) { return units.to_string(); }
    let fraction = format!("{:0>9}", decimals.to_string());
    format!("{}.{}", units, fraction.trim_end_matches('0'))
}

pub struct EgressPolicy<'a> {
    pub configured_chain_id: u64,
    pub configured_vault_id: &'a str,
    pub verified_taker: &'a str,
    pub approved_swap_target: &'a str,
    pub fireblocks_base_asset_id: &'a str,
    pub gas_limit: u64,       // from current simulation plus bounded margin
    pub base_fee_wei: String,
    pub priority_fee_wei: String,
}

pub fn to_fireblocks_request(
    command: &ContractCallCommand,
    policy: EgressPolicy<'_>,
) -> Result<Value> {
    ensure!(command.chain_id == policy.configured_chain_id, "chain mismatch");
    ensure!(command.vault_id == policy.configured_vault_id, "vault mismatch");
    ensure!(address(&command.taker)? == address(policy.verified_taker)?, "vault wallet/taker mismatch");
    ensure!(address(&command.call.to)? == address(policy.approved_swap_target)?, "target not allowlisted");
    ensure!(command.binding_digest == sha256_hex(&serde_json::to_vec(&command.call)?), "call digest mismatch");
    ensure!(command.deadline > Utc::now(), "execution expired");
    ensure!(!policy.fireblocks_base_asset_id.is_empty(), "missing Fireblocks base asset");
    ensure!(policy.gas_limit >= 21_000, "invalid gas limit");
    command.call.validate()?;
    ensure!(uint256(&command.call.value_wei)? == BigUint::from(0u8), "ERC-20 quote requires zero native value");

    let budget = positive_uint256(&command.max_network_fee_wei)?;
    let limit = BigUint::from(policy.gas_limit);
    let fee_cap = &budget / &limit; // floor: gas_limit * fee_cap <= authorized budget
    let base_fee = uint256(&policy.base_fee_wei)?;
    let priority_fee = uint256(&policy.priority_fee_wei)?;
    ensure!(fee_cap >= base_fee + &priority_fee, "gas budget cannot cover current base fee + tip");
    ensure!(fee_cap >= priority_fee, "priority fee above fee cap");

    // Submitting this request is *not* enough to assert execution success.
    // Egress must wait for final receipts and verify actual token deltas.
    Ok(json!({
        "operation": "CONTRACT_CALL",
        "assetId": policy.fireblocks_base_asset_id,
        "source": { "type": "VAULT_ACCOUNT", "id": command.vault_id },
        "destination": {
            "type": "ONE_TIME_ADDRESS",
            "oneTimeAddress": { "address": command.call.to }
        },
        "amount": "0",
        "externalTxId": command.fireblocks_external_tx_id,
        "gasLimit": policy.gas_limit.to_string(),
        "maxFee": wei_as_gwei(&fee_cap),
        "priorityFee": wei_as_gwei(&priority_fee),
        "extraParameters": {"contractCallData": command.call.data}
    }))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn exact_gwei() {
        assert_eq!(wei_as_gwei(&BigUint::from(1234567890u64)), "1.23456789");
        assert_eq!(wei_as_gwei(&BigUint::from(2_000_000_000u64)), "2");
    }
}
