use anyhow::{Context, Result};
use execution_v5_0x_1::{
    domain::{Envelope, ExecuteRequested, QuoteRequested},
    service::ExecutionService,
    store::PgStore,
    zeroex::{OfferProvider, ZeroExProvider},
};
use rdkafka::{
    consumer::{CommitMode, Consumer, StreamConsumer},
    message::Message,
    producer::{FutureProducer, FutureRecord},
    util::Timeout,
    ClientConfig,
};
use serde_json::Value;
use sqlx::Row;
use std::{sync::Arc, time::Duration};
use tracing::{error, info, warn};
use uuid::Uuid;

fn consumer(brokers: &str, group: &str, topic: &str) -> Result<StreamConsumer> {
    let c: StreamConsumer = ClientConfig::new()
        .set("bootstrap.servers", brokers)
        .set("group.id", group)
        .set("enable.auto.commit", "false")
        .set("auto.offset.reset", "earliest")
        .create()?;
    c.subscribe(&[topic])?;
    Ok(c)
}

async fn read_quotes(brokers: String, service: Arc<ExecutionService>) -> Result<()> {
    let c = consumer(&brokers, "execution-v5-0x-1-quotes", "execution.quote.requests.v1")?;
    loop {
        let msg = c.recv().await?;
        let bytes = msg.payload().context("Kafka quote message missing payload")?;
        let envelope: Envelope<QuoteRequested> = serde_json::from_slice(bytes)?;
        anyhow::ensure!(envelope.version == 1, "unsupported quote event version");
        let result = service.quote(envelope.payload).await?;
        info!(?result, "quote saved to transactional outbox");
        c.commit_message(&msg, CommitMode::Async)?;
    }
}

async fn read_authorizations(brokers: String, store: PgStore) -> Result<()> {
    let c = consumer(&brokers, "execution-v5-0x-1-auth", "execution.commands.v1")?;
    loop {
        let msg = c.recv().await?;
        let bytes = msg.payload().context("Kafka authorization missing payload")?;
        let envelope: Envelope<ExecuteRequested> = serde_json::from_slice(bytes)?;
        anyhow::ensure!(envelope.version == 1, "unsupported authorization event version");
        let result = store.authorize(&envelope.payload).await?;
        info!(?result, "authorization handled");
        c.commit_message(&msg, CommitMode::Async)?;
    }
}

async fn publish_outbox(brokers: String, store: PgStore) -> Result<()> {
    let producer: FutureProducer = ClientConfig::new()
        .set("bootstrap.servers", brokers)
        .set("message.timeout.ms", "10000")
        .create()?;
    loop {
        let mut tx = store.pool.begin().await?;
        // One record at a time; the row lock prevents competing workers
        // from publishing the same event concurrently.
        let row = sqlx::query(
            "SELECT event_id,topic,event_key,payload FROM execution_outbox \
             WHERE sent_at IS NULL ORDER BY created_at LIMIT 1 FOR UPDATE SKIP LOCKED"
        ).fetch_optional(&mut *tx).await?;
        let Some(row) = row else {
            tx.commit().await?;
            tokio::time::sleep(Duration::from_millis(250)).await;
            continue;
        };
        let id: Uuid = row.try_get("event_id")?;
        let topic: String = row.try_get("topic")?;
        let key: String = row.try_get("event_key")?;
        let data: sqlx::types::Json<Value> = row.try_get("payload")?;
        let encoded = serde_json::to_string(&data.0)?;
        match producer.send(
            FutureRecord::to(&topic).payload(&encoded).key(&key),
            Timeout::After(Duration::from_secs(10)),
        ).await {
            Ok(_) => {
                sqlx::query("UPDATE execution_outbox SET sent_at=now() WHERE event_id=$1")
                    .bind(id).execute(&mut *tx).await?;
                tx.commit().await?;
            }
            Err((err, _)) => {
                error!(%err, event_id=%id, "Kafka publish failed; leaving event pending");
                tx.rollback().await?;
                tokio::time::sleep(Duration::from_secs(1)).await;
            }
        }
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::try_from_default_env()
            .unwrap_or_else(|_| "info".into()))
        .init();

    let db = std::env::var("DATABASE_URL").context("DATABASE_URL missing")?;
    let brokers = std::env::var("KAFKA_BROKERS").context("KAFKA_BROKERS missing")?;
    let api_key = std::env::var("ZEROX_API_KEY").context("ZEROX_API_KEY missing")?;
    let chain_id: u64 = std::env::var("ZEROX_CHAIN_ID").context("ZEROX_CHAIN_ID missing")?.parse()?;
    let allowance_holder = std::env::var("ZEROX_ALLOWANCE_HOLDER")
        .context("ZEROX_ALLOWANCE_HOLDER missing; must be operator verified for the chain")?;
    let store = PgStore::connect(&db).await?;
    let provider: Arc<dyn OfferProvider> = Arc::new(ZeroExProvider::new(api_key, allowance_holder, chain_id)?);
    let svc = Arc::new(ExecutionService { providers: vec![provider], store: store.clone() });
    warn!("This service emits execution commands. The existing Egress must independently validate and submit them via Fireblocks.");
    tokio::try_join!(
        read_quotes(brokers.clone(), svc),
        read_authorizations(brokers.clone(), store.clone()),
        publish_outbox(brokers, store),
    )?;
    Ok(())
}
