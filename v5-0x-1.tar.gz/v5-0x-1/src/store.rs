use crate::domain::*;
use anyhow::{ensure, Context, Result};
use chrono::Utc;
use serde_json::Value;
use sqlx::{postgres::PgPoolOptions, PgPool, Row};
use uuid::Uuid;

#[derive(Clone)]
pub struct PgStore { pub pool: PgPool }

impl PgStore {
    pub async fn connect(url: &str) -> Result<Self> {
        let pool = PgPoolOptions::new().max_connections(8).connect(url).await?;
        Ok(Self { pool })
    }

    async fn enqueue(
        tx: &mut sqlx::Transaction<'_, sqlx::Postgres>,
        topic: &str, key: &str, correlation_id: Uuid,
        payload: Value, event_id: Uuid,
    ) -> Result<()> {
        let envelope = Envelope {
            version: 1u16,
            message_id: event_id,
            correlation_id,
            created_at: Utc::now(),
            payload,
        };
        sqlx::query("INSERT INTO execution_outbox (event_id, topic, event_key, payload) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING")
            .bind(event_id).bind(topic).bind(key)
            .bind(sqlx::types::Json(serde_json::to_value(envelope)?))
            .execute(&mut **tx).await?;
        Ok(())
    }

    pub async fn save_quote(&self, request_id: Uuid, intent_id: Uuid, request_digest: &str, result: &QuoteResult) -> Result<()> {
        let mut tx = self.pool.begin().await?;
        let inserted = sqlx::query(
            "INSERT INTO execution_quote_requests (request_id,intent_id,request_digest,response) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING"
        ).bind(request_id).bind(intent_id).bind(request_digest).bind(sqlx::types::Json(serde_json::to_value(result)?))
            .execute(&mut *tx).await?.rows_affected();
        if inserted == 0 {
            let row = sqlx::query("SELECT request_digest FROM execution_quote_requests WHERE request_id=$1")
                .bind(request_id).fetch_one(&mut *tx).await?;
            let previous: String = row.try_get("request_digest")?;
            ensure!(previous == request_digest, "request_id reused with different quote request");
            tx.commit().await?;
            return Ok(()); // request-id idempotency
        }
        if let QuoteResult::Offered { offer, .. } = result {
            let state = match &offer.readiness { Readiness::Ready => "ready", Readiness::ApprovalRequired => "approval_required" };
            sqlx::query("INSERT INTO execution_offers (offer_id,request_id,intent_id,strategy_id,state,expires_at,offer) VALUES ($1,$2,$3,$4,$5,$6,$7)")
                .bind(offer.id).bind(request_id).bind(intent_id).bind(&offer.strategy_id)
                .bind(state).bind(offer.expires_at).bind(sqlx::types::Json(serde_json::to_value(offer)?))
                .execute(&mut *tx).await?;
        }
        let event_id = Uuid::new_v5(&request_id, b"execution.quote.results.v1");
        Self::enqueue(
            &mut tx, "execution.quote.results.v1", &intent_id.to_string(),
            request_id, serde_json::to_value(result)?, event_id,
        ).await?;
        tx.commit().await?;
        Ok(())
    }

    // Validate/capture strategy authorization transactionally before Egress.
    // Egress owns the real chain/custody enforcement and settlement status.
    pub async fn authorize(&self, req: &ExecuteRequested) -> Result<AuthorizationResult> {
        positive_uint256(&req.min_buy_amount)?;
        positive_uint256(&req.max_network_fee_wei)?;
        let request_digest = sha256_hex(&serde_json::to_vec(req)?);
        let mut tx = self.pool.begin().await?;
        let existing = sqlx::query("SELECT request_digest,response FROM execution_authorizations WHERE execution_id=$1 FOR UPDATE")
            .bind(req.execution_id).fetch_optional(&mut *tx).await?;
        if let Some(row) = existing {
            let previous: String = row.try_get("request_digest")?;
            ensure!(previous == request_digest, "execution_id reused with different command");
            let json: sqlx::types::Json<Value> = row.try_get("response")?;
            let previous: AuthorizationResult = serde_json::from_value(json.0)?;
            tx.commit().await?;
            return Ok(previous);
        }
        let row = sqlx::query("SELECT state,offer FROM execution_offers WHERE offer_id=$1 FOR UPDATE")
            .bind(req.offer_id).fetch_optional(&mut *tx).await?;

        let mut accepted_offer: Option<ExecutionOffer> = None;
        let reason = match row {
            None => Some("unknown offer".to_string()),
            Some(row) => {
                let state: String = row.try_get("state")?;
                let json: sqlx::types::Json<Value> = row.try_get("offer")?;
                let offer: ExecutionOffer = serde_json::from_value(json.0)?;
                if state != "ready" || offer.readiness != Readiness::Ready {
                    Some("offer not ready, requires approval or already consumed".into())
                } else if offer.expires_at <= Utc::now() || req.deadline <= Utc::now() {
                    Some("quote or authorization expired".into())
                } else if req.strategy_id != offer.strategy_id {
                    Some("strategy mismatch".into())
                } else if positive_uint256(&req.min_buy_amount)? > positive_uint256(&offer.quote.minimum_buy_amount)? {
                    // Cannot demand a tighter on-chain min than 0x encoded.
                    Some("minimum exceeds 0x on-chain slippage floor; re-quote".into())
                } else if positive_uint256(&req.max_network_fee_wei)? < uint256(&offer.quote.estimated_network_fee_wei)? {
                    Some("fee authorization below quoted network cost".into())
                } else if offer.validate_binding().is_err() {
                    Some("quote binding tampered".into())
                } else {
                    accepted_offer = Some(offer);
                    None
                }
            }
        };
        let accepted = reason.is_none();
        let result = match reason {
            Some(reason) => AuthorizationResult::Rejected { execution_id: req.execution_id, reason },
            None => AuthorizationResult::Accepted { execution_id: req.execution_id, offer_id: req.offer_id },
        };

        if let Some(offer) = accepted_offer {
            let updated = sqlx::query("UPDATE execution_offers SET state='consumed' WHERE offer_id=$1 AND state='ready'")
                .bind(offer.id).execute(&mut *tx).await?.rows_affected();
            ensure!(updated == 1, "concurrent offer consumption");

            // Egress must validate vault/taker binding, allowance, balances,
            // current market conditions and on-chain fee limits before submission.
            let command = ContractCallCommand {
                execution_id: req.execution_id,
                offer_id: offer.id,
                chain_id: offer.route.chain_id,
                vault_id: offer.vault_id.clone(),
                taker: offer.route.taker.clone(),
                call: offer.binding.swap.clone(),
                binding_digest: offer.binding.payload_digest.clone(),
                min_buy_amount: req.min_buy_amount.clone(),
                buy_token: offer.route.buy_token.clone(),
                sell_token: offer.route.sell_token.clone(),
                sell_amount: offer.route.sell_amount.clone(),
                max_network_fee_wei: req.max_network_fee_wei.clone(),
                deadline: req.deadline.min(offer.expires_at),
                fireblocks_external_tx_id: format!("swap:{}:0", req.execution_id),
            };
            Self::enqueue(
                &mut tx, "execution.egress.commands.v1", &offer.intent_id.to_string(),
                req.execution_id, serde_json::to_value(command)?,
                Uuid::new_v5(&req.execution_id, b"egress.swap"),
            ).await?;
        }

        sqlx::query("INSERT INTO execution_authorizations(execution_id,offer_id,request_digest,response,accepted) VALUES($1,$2,$3,$4,$5)")
            .bind(req.execution_id).bind(req.offer_id).bind(request_digest)
            .bind(sqlx::types::Json(serde_json::to_value(&result)?)).bind(accepted)
            .execute(&mut *tx).await.context("inserting execution authorization")?;
        Self::enqueue(
            &mut tx, "execution.authorization.results.v1", &req.offer_id.to_string(),
            req.execution_id, serde_json::to_value(&result)?,
            Uuid::new_v5(&req.execution_id, b"authorization.result"),
        ).await?;
        tx.commit().await?;
        Ok(result)
    }
}
