-- Apply with: psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/001_initial.sql
-- PostgreSQL is authoritative. Outbox publishes Kafka messages at least once.
CREATE TABLE IF NOT EXISTS execution_quote_requests (
    request_id UUID PRIMARY KEY,
    intent_id UUID NOT NULL,
    request_digest TEXT NOT NULL,
    response JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS execution_offers (
    offer_id UUID PRIMARY KEY,
    request_id UUID NOT NULL UNIQUE REFERENCES execution_quote_requests(request_id),
    intent_id UUID NOT NULL,
    strategy_id TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('ready','approval_required','consumed')),
    expires_at TIMESTAMPTZ NOT NULL,
    offer JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS execution_authorizations (
    execution_id UUID PRIMARY KEY,
    offer_id UUID NOT NULL,
    request_digest TEXT NOT NULL,
    response JSONB NOT NULL,
    accepted BOOLEAN NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS execution_offer_consumed_once
    ON execution_authorizations(offer_id) WHERE accepted;

CREATE TABLE IF NOT EXISTS execution_outbox (
    event_id UUID PRIMARY KEY,
    topic TEXT NOT NULL,
    event_key TEXT NOT NULL,
    payload JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    sent_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS execution_outbox_pending
    ON execution_outbox(created_at) WHERE sent_at IS NULL;
