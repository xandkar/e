# Execution V1–V5: Rust reference implementation

One Rust package, selected with **`clap` derive**: `--engine v1|v2|v3|v4|v5`.
A common `Intent`, `Offer`, `Binding`, `OfferProvider` and `EgressCommand` wire protocol is used for all implementations. `v5` wraps the existing 0x Swap API v2/AllowanceHolder implementation. **This is a prototype and is NOT an audited production trading engine.**

## What is actually implemented

| Engine | Supported intent | Planner | Quoting |
|---|---|---|---|
| `v1` | `reallocate` | One fixed, Aave-V3-style withdraw → approve → supply route, same ERC-20 on one EVM chain | Configured gas budgets × fee rate |
| `v2` | `reallocate` | Same route | Last 100 successful receipts per chain/contract/op; median and P95+30%, fallback when <20 observations |
| `v3` | `reallocate` | Same route; designed for future multi-route planners | Real RPC `eth_estimateGas` for independent withdraw/approve, V2 history for dependent supply |
| `v4` | `reallocate` | Same route, with dynamic `PriorOutput` references | Execute 3 transactions sequentially on a **local Anvil fork**, measure wallet asset delta and each receipt; 2x gas-price sensitivity |
| `v5` | `swap` | 0x externally chooses swap liquidity route | 0x API v2 `/swap/allowance-holder/quote`, including net output, floor, fees and calldata |

**Scope differences are deliberate.** 0x is a swap router, not a lending-position planner. V1–V4 here are a restricted same-asset lending prototype. Select `v5` for exact-input ERC-20 swaps; `v1`–`v4` for supported lending movements. Attempting the other intent type returns a `failures` record, not a fabricated route. Although the *contract* is interchangeable, provider capabilities are not interchangeable for every intent.

V3's **interface** supports `Vec<Offer>`, but this concrete native planner produces one direct route because it has no legitimate alternate for its narrow same-asset objective. V4 supports sequential state mutation, but **not** arbitrary recipe DAGs, ERC-4626 accounting, cross-chain plans, adverse-pool-state scenario generation, atomic flash-loan migrations, or comprehensive portfolio/debt accounting. The only stress result implemented is a 2x network-fee sensitivity. These are explicit next steps, not hidden stubs masquerading as features.

## Project structure

```
Cargo.toml
src/
  main.rs      # clap derive, quote / serve / record-gas subcommands
  model.rs     # common intent, offer, economics, binding, authorization, wire v2
  provider.rs  # OfferProvider trait + 0x normalization adapter
  interfaces.rs # Planner and Quoter sub-interfaces + FixedAavePlanner
  native.rs    # native route and V1–V4 gas / simulation implementations
  rpc.rs       # JSON-RPC: gas estimation, Anvil fork simulation and receipts
  zeroex.rs    # preserved 0x Swap API v2/AllowanceHolder adapter
  swap.rs      # preserved V5.0x.1 swap-domain validation and calldata binding
  service.rs   # provider-independent offer generation, response normalization
  store.rs     # PostgreSQL offers, one-time authorization, outbox, gas receipts
  egress.rs    # preserved Fireblocks CONTRACT_CALL request builder (not a signer)
migrations/001_initial.sql
examples/native_policy.json
examples/gas_history.json
tests/native_tests.rs
tests/fixtures/
```

## Prerequisites

Rust stable supporting `u64::div_ceil` (Rust 1.73+), Cargo, PostgreSQL, Kafka (for `serve`), an EVM RPC for V3, **local Anvil fork** for V4, 0x API credentials for V5.

Build/test:

```sh
cargo fmt --all -- --check
cargo test
cargo build --release
cargo run -- --help
```

### CLI examples

For **offline V1** using placeholder contract addresses and an explicitly illustrative 1 Gwei rate:

```sh
cargo run -- --engine v1 quote --input tests/fixtures/reallocate.json
```

For **V2**, using the provided one-sample-per-operation history (so the documented cold-start fallback activates):

```sh
cargo run -- --engine v2 --history-file examples/gas_history.json \
  quote --input tests/fixtures/reallocate.json
```

To use a *live* fee rate with V1/V2, add `--rpc-url "$RPC_URL"`. For V2 to learn from the PostgreSQL receipt table, also set `DATABASE_URL`; the `quote` subcommand reads it but does not persist offers. `serve` persists offers.

For **V3**:

```sh
cargo run -- --engine v3 --rpc-url "$RPC_URL" \
  quote --input tests/fixtures/reallocate.json
```

V3 needs a real supported token, market contracts, and a real custody-controlled wallet with withdrawal rights; the provided placeholder addresses won't simulate successfully. A genuine revert fails the quote rather than silently substituting history.

For **V4**, launch a dedicated **Anvil fork** at a pinned block, using a wallet that already owns the source position (a local impersonated wallet can submit on the fork). Example:

```sh
anvil --fork-url "$RPC_URL" --fork-block-number 23000000 --port 8545
cargo run -- --engine v4 --fork-rpc-url http://127.0.0.1:8545 \
  quote --input tests/fixtures/reallocate.json
```

Choose a supported fork block for your environment; the block number above is illustrative, not a recommended fixed production snapshot. V4 refuses remote/public fork URLs. It calls `evm_snapshot`, impersonates the wallet, executes the withdrawal, approval and supply on that fork, inspects the withdrawal balance delta, and **always attempts to revert its snapshot**, including on simulation failure. Use a dedicated single-tenant Anvil node, not a shared chain state or a production RPC. Real contract calls only succeed when the forked account and protocols meet the underlying conditions.

For **V5**, using the current 0x v2 AllowanceHolder quote API:

```sh
export ZEROX_API_KEY='your-key'
export ZEROX_CHAIN_ID=1
export ZEROX_ALLOWANCE_HOLDER='verify-deployment-address-for-your-chain'
cargo run -- --engine v5 quote --input tests/fixtures/swap.json
```

The sample taker may not own enough tokens; the 0x adapter intentionally fails the request in that situation. Allowance issues produce `readiness=approval_required` and require a separate approval and fresh quote.

**Do not use example addresses for trading.** Edit `examples/native_policy.json` with vetted market and token addresses; keep protocol/chain ownership checks in your actual Egress. Even a correct quote does not authorize Fireblocks to act.

## Kafka + PostgreSQL

```sh
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/001_initial.sql
cargo run -- --engine v2 serve
```

Canonical wire format is `WireEnvelope<T>`, `version: 2` (because V5.0x.1's v1 payload only knew swaps and singular offers). Create and ACL these topics:

- `execution.quote.requests.v2` — request, keyed by intent ID
- `execution.quote.results.v2` — quote batch with zero or more offers and failures
- `execution.commands.v2` — authorize one `offer_id` with constraints
- `execution.authorization.results.v2` — accepted/rejected
- `execution.egress.commands.v2` — **authorization handoff only**, must be consumed by your real Fireblocks Egress

The separate `--engine` CLI value is **not** the wire schema version. To deploy multiple quote engines simultaneously, use separate input quote topics (`--quote-topic ...`), configured strategy-side routing and one authoritative authorization worker for the shared DB. Avoid duplicate workers consuming all the same requests in separate consumer groups unintentionally. The bundled `serve` runs all three loops together; for true concurrent multi-backend deployments, split its authorization/outbox roles into a singleton deployment.

`src/store.rs` records all offers in one PostgreSQL transaction with the request deduplication record and outbox event. Repeating a request ID with identical content returns its **original persisted** offers. Different content under the same ID is rejected. Authorizations lock the offer row, require unexpired `ready` status, compare the strategy and economic bounds, consume an offer at most once, and enqueue a provider-bound `EgressCommand`. Outbox delivery is at least once and every Egress execution must be idempotent.

**Observation ingestion for V2:** the actual execution/reconciliation service should obtain finalized receipts from a trusted RPC and record `(chain_id, tx_hash, contract, operation, gas_used, succeeded)` into `execution_gas_observations` (see `GasReceipt`). To manually ingest one **verified** observation:

```sh
cargo run -- record-gas --input examples/verified_receipt.json
```

`record-gas` requires `DATABASE_URL`. The CLI validates structure and deduplicates tx hashes; it **does not independently fetch or prove** the receipt. Production must restrict it to a trusted reconciliation source. V2/V3 queries the last 100 successful 30-day observations keyed by chain, contract, operation, automatically excluding reverted transactions. The local JSON history fixture is an alternative for offline demos.

The `EgressCommand.binding` is either:

- `native_recipe`: an immutable three-step recipe with `amount: fixed | prior_output`, gas limits and a digest.
- `zero_ex`: the complete 0x offer with verified allowance-holder target and digest-bound calldata.

The existing `src/egress.rs` remains a pure Fireblocks `CONTRACT_CALL` body constructor for the legacy swap command. Real Egress must map canonical `EgressCommand` to its execution steps, then use the Fireblocks builder/SDK after independently revalidating on-chain state, risk limits and custody policy. The package intentionally **does not submit, sign, or confirm Fireblocks transactions**.

## Important safety and economic constraints

- Native V1–V4 support **only standard non-rebasing, non-fee-on-transfer ERC-20 underlying assets on an approved Aave-V3-style Pool deployment**. Pool configuration, contract code identity, account health and position ownership are operator-validated; this prototype does *not* implement all production preflights.
- Native quote `expected_output_units` assumes the amount withdrawn can be supplied in full. V4 derives it from the actual simulated wallet delta; V1–V3 assume exact transfer amounts. V1–V3 do **not** independently calculate protocol fees, collateral effects, or risk-adjusted portfolio value. Missing estimates are **unknown**, not an assurance that costs are zero.
- Three native steps are **three real Fireblocks transactions** unless your Egress has an atomic smart-contract router. A withdrawal may complete while the deposit fails. Egress must reconcile and recover partial positions.
- In V4, `PriorOutput` amounts must be recomputed from **real finalized chain data** and constrained by the authorized recipe; the preliminary `estimated_call` is not itself an execution authorization. Never trust an unverified Kafka message alone: look up the offer in PostgreSQL and validate contract allowlists and the digest.
- Gas limits are indicative budgets. Fee-rate changes, L2 data fees, EVM state and approval semantics can invalidate estimates. An on-chain revert can still consume gas. V4 snapshot simulation is **hypothetical**, not a proof of future inclusion or successful execution.
- 0x `minBuyAmount` is the on-chain quote floor and can expire with changing liquidity. The 0x API may return `issues` and simulation warnings. Never approve the Settler contract as a spender. Verify the chain-specific AllowanceHolder deployment separately. Do not use Permit2 without adding its typed-signature workflow.
- Quotes expire; Fireblocks signing/approval may exceed quote lifetime. Execution must revalidate min output, gas budget, transaction recipient, calldata, spender, wallet/vault identity, balances, allowances, and actual receipts immediately prior to each step.
- Do not interpret `Readiness::Ready` as a guarantee of spendable funds; it means no *known provider-side* approval blocker. Recheck at submission.
- Example fixture UUIDs, addresses, prices and historical samples are **synthetic**. Do not use them to transfer real funds.
- `serve` exits on malformed Kafka payloads; add a DLQ/poison message policy, retries, timeouts, metrics, health endpoints, ACLs and migration rollbacks before production.

## Extension points

`provider::OfferProvider` is the stable cross-version interface:

```rust
#[async_trait::async_trait]
pub trait OfferProvider: Send + Sync {
    fn version(&self) -> Version;
    fn name(&self) -> &'static str;
    async fn offers(&self, intent: &Intent) -> Result<Vec<Offer>>;
}
```

New providers can produce a canonical offer with versioned provenance, economic assumptions, expiry, and a binding accepted by your Egress. The current native planner is intentionally conservative and single-route; add planners for multiple candidates without changing the strategy or Kafka response structure. `interfaces::Planner` and `interfaces::Quoter` are also implemented and used by the native adapter (`FixedAavePlanner` + `NativeProvider` quoter). They accept a `NativePlan` containing the route operations. The quoter currently recognizes only the fixed supported route; multi-route discovery and independent runtime selection of arbitrary planner/quoter pairings remain follow-on work. **This package supports whole-provider CLI selection now and compile-time component substitution for capable native routes.**

## Build verification status

The code and fixtures have been generated and statically inspected. This environment does not contain `cargo`/`rustc` and cannot reach crates.io, so compilation, formatting, `cargo test`, real Anvil simulation, PostgreSQL migrations, Kafka delivery and 0x/Fireblocks integration are **not verified here**. Run the commands above on a Rust development host, fix any compile or integration errors before use, and treat this as an architectural reference package until then.

Docs:
- https://docs.0x.org/docs/introduction/quickstart/swap-tokens-with-0x-swap-api
- https://docs.0x.org/docs/upgrading/upgrading-to-swap-v2
- https://getfoundry.sh/anvil/reference/
- https://geth.ethereum.org/docs/interacting-with-geth/rpc/ns-eth
- https://fireblocks.readme.io/reference/createtransaction
