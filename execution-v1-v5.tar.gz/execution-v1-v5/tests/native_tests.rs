use execution_v1_v5::{
    model::{Version,QuoteRequest,Binding,EstimateMethod},
    native::{gas_history,NativePolicy,NativeProvider},
    provider::OfferProvider,
};
use std::path::Path;

fn intent() -> QuoteRequest {
    serde_json::from_str(include_str!("fixtures/reallocate.json")).unwrap()
}
fn policy() -> NativePolicy {
    NativePolicy::from_file(Path::new("examples/native_policy.json")).unwrap()
}
#[tokio::test]
async fn v1_is_static_and_recipe_digest_matches() {
    let provider=NativeProvider::new(Version::V1,policy(),vec![],None,None,"1000000000").unwrap();
    let offers=provider.offers(&intent().intent).await.unwrap();
    let offer=&offers[0];
    assert!(matches!(&offer.economics.method,EstimateMethod::Static));
    assert_eq!(offer.economics.expected_output_units,"100000000");
    assert_eq!(offer.economics.expected_network_fee_wei,"625000000000000");
    assert!(matches!(&offer.binding,Binding::NativeRecipe{steps,..} if steps.len()==3));
    offer.validate().unwrap();
}
#[tokio::test]
async fn v2_falls_back_with_few_observations() {
    let history=gas_history(Some(Path::new("examples/gas_history.json"))).unwrap();
    let provider=NativeProvider::new(Version::V2,policy(),history,None,None,"1000000000").unwrap();
    let offers=provider.offers(&intent().intent).await.unwrap();
    assert!(matches!(&offers[0].economics.method,EstimateMethod::Historical));
    assert_eq!(offers[0].economics.expected_network_fee_wei,"625000000000000");
}
#[test]
fn swap_intent_is_separate_from_lending_intent() {
    let raw: QuoteRequest=serde_json::from_str(include_str!("fixtures/swap.json")).unwrap();
    assert!(raw.intent.validate().is_ok());
}
