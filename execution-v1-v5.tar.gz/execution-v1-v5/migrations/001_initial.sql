-- psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/001_initial.sql
CREATE TABLE IF NOT EXISTS execution_quote_requests (
    request_id UUID PRIMARY KEY,
    intent_id UUID NOT NULL,
    request_digest TEXT NOT NULL,
    response JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS execution_offers (
    offer_id UUID PRIMARY KEY,
    request_id UUID NOT NULL REFERENCES execution_quote_requests(request_id),
    intent_id UUID NOT NULL,
    strategy_id TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('ready','approval_required','consumed')),
    expires_at TIMESTAMPTZ NOT NULL,
    offer JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS execution_offers_request_idx ON execution_offers(request_id);
CREATE TABLE IF NOT EXISTS execution_authorizations (
    execution_id UUID PRIMARY KEY,
    offer_id UUID NOT NULL,
    request_digest TEXT NOT NULL,
    response JSONB NOT NULL,
    accepted BOOLEAN NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS execution_offer_consumed_once
    ON execution_authorizations(offer_id) WHERE accepted;
CREATE TABLE IF NOT EXISTS execution_outbox (
    event_id UUID PRIMARY KEY,
    topic TEXT NOT NULL,
    event_key TEXT NOT NULL,
    payload JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    sent_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS execution_outbox_pending
    ON execution_outbox(created_at) WHERE sent_at IS NULL;
CREATE TABLE IF NOT EXISTS execution_gas_observations (
    chain_id BIGINT NOT NULL,
    tx_hash TEXT NOT NULL,
    step_index INTEGER NOT NULL,
    operation TEXT NOT NULL,
    contract TEXT NOT NULL,
    gas_used BIGINT NOT NULL CHECK (gas_used > 0),
    succeeded BOOLEAN NOT NULL,
    observed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (chain_id,tx_hash)
);
CREATE INDEX IF NOT EXISTS execution_gas_recent_idx
    ON execution_gas_observations(chain_id,operation,contract,observed_at DESC)
    WHERE succeeded;
