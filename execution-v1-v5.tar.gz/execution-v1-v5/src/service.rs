use crate::{model::*, provider::OfferProvider, store::PgStore};
use anyhow::Result;
use std::sync::Arc;

pub struct ExecutionService {
    pub provider: Arc<dyn OfferProvider>,
    pub store: Option<PgStore>,
}
impl ExecutionService {
    pub async fn quote(&self, req: QuoteRequest) -> Result<QuoteBatch> {
        let mut batch = QuoteBatch { request_id: req.request_id, intent_id: req.intent.id(),
            version: self.provider.version(), offers: Vec::new(), failures: Vec::new() };
        if let Err(e) = req.intent.validate() {
            batch.failures.push(format!("INVALID_INTENT: {e}"));
        } else {
            match self.provider.offers(&req.intent).await {
                Ok(offers) => {
                    for offer in offers {
                        if offer.version != self.provider.version() || offer.intent_id != req.intent.id()
                            || offer.strategy_id != req.intent.strategy() || offer.vault_id != req.intent.vault()
                            || offer.chain_id != req.intent.chain() {
                            batch.failures.push("provider returned offer inconsistent with request".into());
                            continue;
                        }
                        match offer.validate() {
                            Ok(()) => batch.offers.push(offer),
                            Err(err) => batch.failures.push(format!("invalid offer: {err}")),
                        }
                    }
                }
                Err(err) => batch.failures.push(format!("{}: {err}", self.provider.name())),
            }
        }
        if let Some(store) = &self.store { return store.save_quote(&req,self.provider.version(),batch).await; }
        Ok(batch)
    }
}
