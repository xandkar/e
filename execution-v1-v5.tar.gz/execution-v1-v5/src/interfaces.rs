//! Optional finer-grained interfaces beneath the stable OfferProvider boundary.
//! Adapters can mix these components only when their plan capabilities match.
use crate::{model::{Intent, Offer, Operation}};
use anyhow::{bail, Result};
use async_trait::async_trait;
use uuid::Uuid;

#[derive(Debug, Clone)]
pub struct NativePlan {
    pub id: Uuid,
    pub intent_id: Uuid,
    pub steps: Vec<Operation>,
}

#[async_trait]
pub trait Planner: Send + Sync {
    async fn plans(&self, intent: &Intent) -> Result<Vec<NativePlan>>;
}

#[async_trait]
pub trait Quoter: Send + Sync {
    async fn quote_plan(&self, intent: &Intent, plan: &NativePlan) -> Result<Offer>;
}

pub struct FixedAavePlanner;
#[async_trait]
impl Planner for FixedAavePlanner {
    async fn plans(&self, intent: &Intent) -> Result<Vec<NativePlan>> {
        let Intent::Reallocate(i) = intent else { bail!("Aave planner supports reallocate only") };
        let steps = vec![Operation::Withdraw,Operation::Approve,Operation::Supply];
        Ok(vec![NativePlan {
            id: Uuid::new_v5(&i.id, b"direct-aave-style-v1"),
            intent_id:i.id, steps,
        }])
    }
}
