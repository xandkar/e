//! Common contract for all five versions. Provider-specific material stays inside bindings.
use crate::swap::{address, positive_uint256, uint256, sha256_hex, EvmCall, SwapIntent};
use anyhow::{ensure, Result};
use chrono::{DateTime, Utc};
use clap::ValueEnum;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Copy, Clone, Serialize, Deserialize, ValueEnum, PartialEq, Eq)]
#[serde(rename_all="snake_case")]
pub enum Version { V1, V2, V3, V4, V5 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReallocateIntent {
    pub id: Uuid,
    pub strategy_id: String,
    pub vault_id: String,
    pub chain_id: u64,
    pub taker: String,
    pub asset: String,
    pub amount: String,
    pub source_pool: String,
    pub destination_pool: String,
}
impl ReallocateIntent {
    pub fn validate(&self) -> Result<()> {
        ensure!(!self.strategy_id.is_empty() && !self.vault_id.is_empty(), "missing identity");
        ensure!(self.chain_id > 0, "chain_id missing");
        for a in [&self.taker, &self.asset, &self.source_pool, &self.destination_pool] { address(a)?; }
        ensure!(address(&self.source_pool)? != address(&self.destination_pool)?, "same pool");
        positive_uint256(&self.amount)?;
        Ok(())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag="kind", content="params", rename_all="snake_case")]
pub enum Intent { Reallocate(ReallocateIntent), Swap(SwapIntent) }
impl Intent {
    pub fn validate(&self) -> Result<()> { match self { Self::Reallocate(i) => i.validate(), Self::Swap(i) => i.validate() } }
    pub fn id(&self) -> Uuid { match self { Self::Reallocate(i) => i.id, Self::Swap(i) => i.id } }
    pub fn strategy(&self) -> &str { match self { Self::Reallocate(i) => &i.strategy_id, Self::Swap(i) => &i.strategy_id } }
    pub fn vault(&self) -> &str { match self { Self::Reallocate(i) => &i.vault_id, Self::Swap(i) => &i.vault_id } }
    pub fn chain(&self) -> u64 { match self { Self::Reallocate(i) => i.chain_id, Self::Swap(i) => i.chain_id } }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuoteRequest { pub request_id: Uuid, pub intent: Intent }

/// Wire schema v2: the v1 quote payload only supported swaps and single offers.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WireEnvelope<T> {
    pub version: u16,
    pub message_id: Uuid,
    pub correlation_id: Uuid,
    pub created_at: DateTime<Utc>,
    pub payload: T,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QuoteBatch {
    pub request_id: Uuid,
    pub intent_id: Uuid,
    pub version: Version,
    pub offers: Vec<Offer>,
    pub failures: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all="snake_case")]
pub enum Readiness { Ready, ApprovalRequired }

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all="snake_case")]
pub enum EstimateMethod { Static, Historical, RpcAndHistory, StatefulFork, ZeroEx }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Economics {
    pub output_token: String,
    pub expected_output_units: String,
    pub minimum_output_units: String,
    pub expected_network_fee_wei: String,
    pub max_network_fee_wei: String,
    pub method: EstimateMethod,
    pub quote_block: Option<u64>,
    // A missing component is unknown, not zero. This MVP supports only
    // fee-free/non-rebasing underlying assets in the native pathway.
    pub assumptions: Vec<String>,
    #[serde(default)]
    pub stress_tests: Vec<StressTest>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StressTest {
    pub scenario: String,
    pub projected_network_fee_wei: String,
    pub notes: String,
}


#[derive(Debug, Copy, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
#[serde(rename_all="snake_case")]
pub enum Operation { Withdraw, Approve, Supply }
impl Operation { pub fn as_str(self) -> &'static str { match self { Self::Withdraw=>"withdraw", Self::Approve=>"approve", Self::Supply=>"supply" } } }

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag="source", rename_all="snake_case")]
pub enum AmountRef { Fixed { units: String }, PriorOutput { step_index: usize } }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecipeStep {
    pub operation: Operation,
    pub contract: String,
    pub token: String,
    pub amount: AmountRef,
    pub estimated_gas: u64,
    pub gas_limit: u64,
    // Determined at quoting time for audit, but live Egress must recalculate
    // calldata from actual prior outputs and validate bounds.
    pub estimated_call: Option<EvmCall>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag="kind", rename_all="snake_case")]
pub enum Binding {
    NativeRecipe { plan_id: Uuid, steps: Vec<RecipeStep>, recipe_digest: String },
    ZeroEx { swap: crate::swap::ExecutionOffer },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Offer {
    pub id: Uuid,
    pub intent_id: Uuid,
    pub strategy_id: String,
    pub vault_id: String,
    pub version: Version,
    pub provider: String,
    pub readiness: Readiness,
    pub chain_id: u64,
    pub taker: String,
    pub issued_at: DateTime<Utc>,
    pub expires_at: DateTime<Utc>,
    pub economics: Economics,
    pub binding: Binding,
}
impl Offer {
    pub fn validate(&self) -> Result<()> {
        ensure!(self.expires_at > self.issued_at, "invalid quote lifetime");
        ensure!(self.chain_id > 0 && self.provider.len()>0, "invalid metadata");
        address(&self.taker)?;
        address(&self.economics.output_token)?;
        positive_uint256(&self.economics.expected_output_units)?;
        positive_uint256(&self.economics.minimum_output_units)?;
        ensure!(uint256(&self.economics.minimum_output_units)? <= uint256(&self.economics.expected_output_units)?, "min output above expected");
        uint256(&self.economics.expected_network_fee_wei)?;
        uint256(&self.economics.max_network_fee_wei)?;
        match &self.binding {
            Binding::NativeRecipe { steps, recipe_digest, .. } => {
                ensure!(!steps.is_empty(), "empty recipe");
                ensure!(*recipe_digest == sha256_hex(&serde_json::to_vec(steps)?), "invalid recipe digest");
            }
            Binding::ZeroEx { swap } => swap.validate_binding()?,
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecuteRequested {
    pub execution_id: Uuid,
    pub offer_id: Uuid,
    pub strategy_id: String,
    pub min_received_units: String,
    pub max_network_fee_wei: String,
    pub deadline: DateTime<Utc>,
}
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag="type", rename_all="snake_case")]
pub enum AuthorizationResult {
    Accepted { execution_id: Uuid, offer_id: Uuid },
    Rejected { execution_id: Uuid, reason: String },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EgressCommand {
    pub execution_id: Uuid,
    pub offer_id: Uuid,
    pub binding: Binding,
    pub strategy_id: String,
    pub vault_id: String,
    pub chain_id: u64,
    pub taker: String,
    pub min_received_units: String,
    pub max_network_fee_wei: String,
    pub deadline: DateTime<Utc>,
}
