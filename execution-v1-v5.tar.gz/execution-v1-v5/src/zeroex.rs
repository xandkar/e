use crate::swap::*;
use anyhow::{bail, ensure, Context, Result};
use async_trait::async_trait;
use chrono::{Duration, Utc};
use serde::Deserialize;
use serde_json::Value;

#[async_trait]
pub trait OfferProvider: Send + Sync {
    fn name(&self) -> &'static str;
    async fn offers(&self, intent: &SwapIntent) -> Result<Vec<ExecutionOffer>>;
}

#[derive(Clone)]
pub struct ZeroExProvider {
    client: reqwest::Client,
    api_key: String,
    base_url: String,
    allowance_holder: String,
    chain_id: u64,
    quote_ttl_seconds: i64,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ZeroExIssues {
    allowance: Option<AllowanceIssue>,
    balance: Option<Value>,
    #[serde(default)]
    simulation_incomplete: bool,
}

#[derive(Debug, Deserialize)]
struct AllowanceIssue { spender: String }

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ZeroExTransaction {
    to: String,
    data: String,
    value: String,
    gas: String,
    gas_price: String,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct ZeroExQuote {
    #[serde(default)]
    liquidity_available: bool,
    buy_token: Option<String>,
    sell_token: Option<String>,
    sell_amount: Option<String>,
    buy_amount: Option<String>,
    min_buy_amount: Option<String>,
    total_network_fee: Option<String>,
    block_number: Option<String>,
    allowance_target: Option<String>,
    issues: Option<ZeroExIssues>,
    transaction: Option<ZeroExTransaction>,
    #[serde(default)]
    fees: Value,
}

impl ZeroExProvider {
    pub fn new(api_key: String, allowance_holder: String, chain_id: u64) -> Result<Self> {
        ensure!(!api_key.is_empty(), "missing 0x API key");
        ensure!(chain_id != 0, "missing configured chain id");
        let client = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(12))
            .build()?;
        Ok(Self {
            client,
            api_key,
            base_url: "https://api.0x.org".into(),
            allowance_holder: address(&allowance_holder)?,
            chain_id,
            quote_ttl_seconds: 25,
        })
    }

    /// URL override for local mock servers and integration tests; do not use
    /// in production with an untrusted HTTP origin.
    pub fn with_base_url(mut self, url: String) -> Self {
        self.base_url = url.trim_end_matches('/').into();
        self
    }

    async fn raw_quote(&self, intent: &SwapIntent) -> Result<ZeroExQuote> {
        let url = format!("{}/swap/allowance-holder/quote", self.base_url);
        let response = self.client.get(url)
            .header("0x-api-key", &self.api_key)
            .header("0x-version", "v2")
            .query(&[
                ("chainId", intent.chain_id.to_string()),
                ("taker", address(&intent.taker)?),
                ("sellToken", address(&intent.sell_token)?),
                ("buyToken", address(&intent.buy_token)?),
                ("sellAmount", intent.sell_amount.clone()),
                ("slippageBps", intent.slippage_bps.to_string()),
            ])
            .send().await.context("0x request failed")?;
        let status = response.status();
        if !status.is_success() {
            let body = response.text().await.unwrap_or_default();
            bail!("0x HTTP {status}: {}", body.chars().take(300).collect::<String>());
        }
        response.json().await.context("invalid 0x response")
    }

    fn normalize(&self, intent: &SwapIntent, raw: ZeroExQuote) -> Result<ExecutionOffer> {
        ensure!(raw.liquidity_available, "0x reports no route/liquidity");
        let issues = raw.issues.context("0x response missing issues")?;
        ensure!(issues.balance.is_none(), "taker balance insufficient; fund wallet/withdraw first and re-quote");
        ensure!(!issues.simulation_incomplete, "0x could not complete quote simulation");

        ensure!(address(raw.sell_token.as_deref().context("missing sell token")?)? == address(&intent.sell_token)?, "0x changed sell token");
        ensure!(address(raw.buy_token.as_deref().context("missing buy token")?)? == address(&intent.buy_token)?, "0x changed buy token");
        ensure!(positive_uint256(raw.sell_amount.as_deref().context("missing sell amount")?)? == positive_uint256(&intent.sell_amount)?, "0x changed sell amount");

        let expected = raw.buy_amount.context("missing buyAmount")?;
        let minimum = raw.min_buy_amount.context("missing minBuyAmount")?;
        let expected_n = positive_uint256(&expected)?;
        let minimum_n = positive_uint256(&minimum)?;
        ensure!(minimum_n <= expected_n, "invalid minimum output");

        // Fail closed on changes to the authorized contract deployment.
        let transaction = raw.transaction.context("0x response omitted executable transaction")?;
        let target = address(&transaction.to)?;
        ensure!(target == self.allowance_holder, "0x executable target not whitelisted AllowanceHolder");
        if let Some(allowance_target) = raw.allowance_target.as_deref() {
            ensure!(address(allowance_target)? == self.allowance_holder, "0x allowance target mismatch");
        }
        let swap = EvmCall {
            to: target,
            data: transaction.data,
            value_wei: transaction.value,
            estimated_gas: transaction.gas,
            quoted_gas_price_wei: transaction.gas_price,
        };
        swap.validate()?;
        ensure!(uint256(&swap.value_wei)? == uint256("0")?, "unexpected native value in ERC-20 swap");

        let approval = match issues.allowance {
            Some(issue) => {
                let spender = address(&issue.spender)?;
                ensure!(spender == self.allowance_holder, "unexpected approval spender");
                let call = erc20_approval(&intent.sell_token, &spender, &intent.sell_amount)?;
                Some(ApprovalRequirement {
                    token: address(&intent.sell_token)?, spender,
                    amount: intent.sell_amount.clone(), call,
                })
            }
            None => None,
        };
        let readiness = if approval.is_some() { Readiness::ApprovalRequired } else { Readiness::Ready };

        let quoted_gas_fee = uint256(&swap.estimated_gas)? * uint256(&swap.quoted_gas_price_wei)?;
        let network = match raw.total_network_fee {
            Some(n) => { uint256(&n)?; n }
            None => quoted_gas_fee.to_str_radix(10),
        };
        let mut fees = Vec::new();
        for kind in ["integratorFee", "zeroExFee", "gasFee"] {
            if let Some(f) = raw.fees.get(kind).filter(|f| !f.is_null()) {
                if let (Some(amount), Some(token)) = (
                    f.get("amount").and_then(Value::as_str),
                    f.get("token").and_then(Value::as_str),
                ) {
                    uint256(amount)?;
                    fees.push(FeeComponent {
                        kind: kind.to_string(),
                        token: address(token)?,
                        amount: amount.into(),
                        // 0x buyAmount is treated as net of 0x's trading fees.
                        // Gas fees charged separately in tokens need separate accounting.
                        included_in_buy_amount: kind != "gasFee",
                    });
                }
            }
        }

        let digest = sha256_hex(&serde_json::to_vec(&swap)?);
        let issued_at = Utc::now();
        Ok(ExecutionOffer {
            id: uuid::Uuid::new_v4(),
            intent_id: intent.id,
            strategy_id: intent.strategy_id.clone(),
            vault_id: intent.vault_id.clone(),
            readiness,
            route: SwapRoute {
                provider: "0x".into(),
                chain_id: intent.chain_id,
                sell_token: address(&intent.sell_token)?,
                buy_token: address(&intent.buy_token)?,
                sell_amount: intent.sell_amount.clone(),
                taker: address(&intent.taker)?,
            },
            quote: EconomicQuote {
                expected_buy_amount: expected,
                minimum_buy_amount: minimum,
                estimated_network_fee_wei: network,
                fees,
                estimation_source: "0x_swap_api_v2".into(),
                source_block_number: raw.block_number,
            },
            binding: ExecutionBinding {
                provider: "0x".into(),
                method: "allowance_holder".into(),
                swap,
                approval,
                payload_digest: digest,
            },
            issued_at,
            expires_at: issued_at + Duration::seconds(self.quote_ttl_seconds),
        })
    }
}

#[async_trait]
impl OfferProvider for ZeroExProvider {
    fn name(&self) -> &'static str { "0x" }

    async fn offers(&self, intent: &SwapIntent) -> Result<Vec<ExecutionOffer>> {
        intent.validate()?;
        ensure!(intent.chain_id == self.chain_id, "chain not configured for this 0x provider");
        let raw = self.raw_quote(intent).await?;
        Ok(vec![self.normalize(intent, raw)?])
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use uuid::Uuid;
    fn intent() -> SwapIntent {
        SwapIntent {
            id: Uuid::nil(), strategy_id: "test".into(), chain_id: 1,
            vault_id: "42".into(),
            taker: "0xd8da6bf26964af9d7eed9e03e53415d37aa96045".into(),
            sell_token: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48".into(),
            buy_token: "0x6b175474e89094c44da98b954eedeac495271d0f".into(),
            sell_amount: "100000000".into(), slippage_bps: 100,
        }
    }
    fn provider() -> ZeroExProvider {
        ZeroExProvider::new("dummy".into(), "0x0000000000001ff3684f28c67538d4d072c22734".into(), 1).unwrap()
    }
    fn mock_raw() -> ZeroExQuote {
        serde_json::from_str(include_str!("../tests/fixtures/quote.json")).unwrap()
    }
    #[test]
    fn normalizes_a_ready_swap() {
        let offer = provider().normalize(&intent(), mock_raw()).unwrap();
        assert_eq!(offer.readiness, Readiness::Ready);
        assert_eq!(offer.quote.expected_buy_amount, "99950000000000000000");
        offer.validate_binding().unwrap();
    }
    #[test]
    fn missing_allowance_requires_new_quote_after_approval() {
        let mut raw = mock_raw();
        raw.issues.as_mut().unwrap().allowance = Some(AllowanceIssue {
            spender: "0x0000000000001ff3684f28c67538d4d072c22734".into(),
        });
        let offer = provider().normalize(&intent(), raw).unwrap();
        assert_eq!(offer.readiness, Readiness::ApprovalRequired);
        assert!(offer.binding.approval.unwrap().call.data.starts_with("0x095ea7b3"));
    }
    #[test]
    fn fails_closed_on_wrong_target_and_balance() {
        let mut raw = mock_raw();
        raw.transaction.as_mut().unwrap().to = "0xdead00000000000000000000000000000000dead".into();
        assert!(provider().normalize(&intent(), raw).is_err());
        let mut raw = mock_raw();
        raw.issues.as_mut().unwrap().balance = Some(serde_json::json!({ "actual": "0" }));
        assert!(provider().normalize(&intent(), raw).is_err());
    }
}
