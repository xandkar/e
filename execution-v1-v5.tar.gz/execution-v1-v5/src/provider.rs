use crate::{model::*, zeroex::{OfferProvider as ZeroExOfferProvider, ZeroExProvider}};
use anyhow::{bail, Result};
use async_trait::async_trait;

#[async_trait]
pub trait OfferProvider: Send + Sync {
    fn version(&self) -> Version;
    fn name(&self) -> &'static str;
    async fn offers(&self, intent: &Intent) -> Result<Vec<Offer>>;
}

pub struct ZeroExAdapter { pub inner: ZeroExProvider }
#[async_trait]
impl OfferProvider for ZeroExAdapter {
    fn version(&self) -> Version { Version::V5 }
    fn name(&self) -> &'static str { "0x" }
    async fn offers(&self, intent: &Intent) -> Result<Vec<Offer>> {
        let Intent::Swap(swap) = intent else { bail!("v5/0x supports swap intents only; no lending withdrawals or supplies") };
        let offers = self.inner.offers(swap).await?;
        let mut result = Vec::new();
        for offer in offers {
            let canonical = Offer {
                id: offer.id, intent_id: offer.intent_id,
                strategy_id: offer.strategy_id.clone(), vault_id: offer.vault_id.clone(),
                version: Version::V5, provider: "0x".into(),
                readiness: match &offer.readiness {
                    crate::swap::Readiness::Ready => Readiness::Ready,
                    crate::swap::Readiness::ApprovalRequired => Readiness::ApprovalRequired,
                },
                chain_id: swap.chain_id, taker: swap.taker.clone(),
                issued_at: offer.issued_at.clone(), expires_at: offer.expires_at.clone(),
                economics: Economics {
                    output_token: swap.buy_token.clone(),
                    expected_output_units: offer.quote.expected_buy_amount.clone(),
                    minimum_output_units: offer.quote.minimum_buy_amount.clone(),
                    expected_network_fee_wei: offer.quote.estimated_network_fee_wei.clone(),
                    max_network_fee_wei: offer.quote.estimated_network_fee_wei.clone(),
                    method: EstimateMethod::ZeroEx,
                    quote_block: offer.quote.source_block_number.as_ref().and_then(|s| s.parse::<u64>().ok()),
                    stress_tests: vec![],
                    assumptions: vec![
                        "0x minimum buy amount is calldata-enforced; estimated network fee is indicative, not a hard cap".into(),
                        "Approvals require separate custody operation and a fresh quote".into(),
                    ],
                },
                binding: Binding::ZeroEx { swap: offer },
            };
            canonical.validate()?;
            result.push(canonical);
        }
        Ok(result)
    }
}
