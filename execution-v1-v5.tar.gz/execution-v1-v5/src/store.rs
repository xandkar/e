//! PostgreSQL authoritative offer/authorization store + transactional Kafka outbox.
use crate::{model::*, swap::{positive_uint256, uint256, sha256_hex}};
use anyhow::{ensure, Context, Result};
use chrono::Utc;
use serde::{Serialize, Deserialize};
use serde_json::Value;
use sqlx::{postgres::PgPoolOptions, PgPool, Row};
use uuid::Uuid;

#[derive(Clone)]
pub struct PgStore { pub pool: PgPool }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GasReceipt {
    pub chain_id: u64,
    pub tx_hash: String,
    pub step_index: i32,
    pub operation: Operation,
    pub contract: String,
    pub gas_used: u64,
    pub succeeded: bool,
}

impl PgStore {
    pub async fn connect(url: &str) -> Result<Self> {
        Ok(Self { pool: PgPoolOptions::new().max_connections(8).connect(url).await? })
    }

    async fn enqueue(tx: &mut sqlx::Transaction<'_, sqlx::Postgres>, topic: &str, key: &str,
        correlation_id: Uuid, event_id: Uuid, payload: Value) -> Result<()> {
        let envelope = WireEnvelope { version:2u16, message_id:event_id, correlation_id, created_at:Utc::now(), payload };
        sqlx::query("INSERT INTO execution_outbox(event_id,topic,event_key,payload) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING")
            .bind(event_id).bind(topic).bind(key).bind(sqlx::types::Json(serde_json::to_value(envelope)?))
            .execute(&mut **tx).await?;
        Ok(())
    }
    pub async fn save_quote(&self, request: &QuoteRequest, version: Version, batch: QuoteBatch) -> Result<QuoteBatch> {
        let digest = sha256_hex(&serde_json::to_vec(&(version, request))?);
        let mut tx = self.pool.begin().await?;
        let inserted = sqlx::query("INSERT INTO execution_quote_requests(request_id,intent_id,request_digest,response) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING")
            .bind(request.request_id).bind(request.intent.id()).bind(&digest)
            .bind(sqlx::types::Json(serde_json::to_value(&batch)?))
            .execute(&mut *tx).await?.rows_affected();
        if inserted == 0 {
            let row = sqlx::query("SELECT request_digest,response FROM execution_quote_requests WHERE request_id=$1")
                .bind(request.request_id).fetch_one(&mut *tx).await?;
            let prev: String = row.try_get("request_digest")?;
            ensure!(prev == digest, "request_id reused with different version/payload");
            let saved: sqlx::types::Json<QuoteBatch> = row.try_get("response")?;
            tx.commit().await?;
            return Ok(saved.0);
        }
        for offer in &batch.offers {
            offer.validate()?;
            let state = if offer.readiness == Readiness::Ready { "ready" } else { "approval_required" };
            sqlx::query("INSERT INTO execution_offers(offer_id,request_id,intent_id,strategy_id,state,expires_at,offer) VALUES($1,$2,$3,$4,$5,$6,$7)")
                .bind(offer.id).bind(request.request_id).bind(offer.intent_id).bind(&offer.strategy_id)
                .bind(state).bind(offer.expires_at).bind(sqlx::types::Json(serde_json::to_value(offer)?))
                .execute(&mut *tx).await?;
        }
        Self::enqueue(&mut tx,"execution.quote.results.v2",&batch.intent_id.to_string(),request.request_id,
            Uuid::new_v5(&request.request_id,b"quote.batch"), serde_json::to_value(&batch)?).await?;
        tx.commit().await?;
        Ok(batch)
    }
    pub async fn authorize(&self, req: &ExecuteRequested) -> Result<AuthorizationResult> {
        positive_uint256(&req.min_received_units)?;
        positive_uint256(&req.max_network_fee_wei)?;
        let digest = sha256_hex(&serde_json::to_vec(req)?);
        let mut tx = self.pool.begin().await?;
        let existing = sqlx::query("SELECT request_digest,response FROM execution_authorizations WHERE execution_id=$1 FOR UPDATE")
            .bind(req.execution_id).fetch_optional(&mut *tx).await?;
        if let Some(row) = existing {
            let previous: String = row.try_get("request_digest")?;
            ensure!(previous==digest, "execution_id reused for different command");
            let saved: sqlx::types::Json<AuthorizationResult> = row.try_get("response")?;
            tx.commit().await?;
            return Ok(saved.0);
        }
        let row = sqlx::query("SELECT state,offer FROM execution_offers WHERE offer_id=$1 FOR UPDATE")
            .bind(req.offer_id).fetch_optional(&mut *tx).await?;
        let mut authorized: Option<Offer> = None;
        let reason: Option<String> = match row {
            None => Some("unknown offer".into()),
            Some(row) => {
                let state: String = row.try_get("state")?;
                let raw: sqlx::types::Json<Offer> = row.try_get("offer")?;
                let offer = raw.0;
                if state != "ready" || offer.readiness != Readiness::Ready { Some("offer not ready or already consumed".into()) }
                else if req.deadline <= Utc::now() || offer.expires_at <= Utc::now() { Some("quote/authorization expired".into()) }
                else if req.strategy_id != offer.strategy_id { Some("strategy mismatch".into()) }
                else if uint256(&req.min_received_units)? > uint256(&offer.economics.minimum_output_units)? {
                    Some("required minimum exceeds provider's authorized output floor; re-quote".into())
                } else if uint256(&req.max_network_fee_wei)? < uint256(&offer.economics.expected_network_fee_wei)? {
                    Some("fee limit below indicative cost".into())
                } else if let Err(err) = offer.validate() { Some(format!("invalid binding: {err}")) }
                else { authorized = Some(offer); None }
            }
        };
        let accepted = reason.is_none();
        let result = match reason {
            Some(reason)=>AuthorizationResult::Rejected {execution_id:req.execution_id,reason},
            None=>AuthorizationResult::Accepted {execution_id:req.execution_id,offer_id:req.offer_id},
        };
        if let Some(offer) = authorized {
            let updated = sqlx::query("UPDATE execution_offers SET state='consumed' WHERE offer_id=$1 AND state='ready'")
                .bind(offer.id).execute(&mut *tx).await?.rows_affected();
            ensure!(updated==1, "concurrent offer consumption");
            let cmd = EgressCommand {
                execution_id:req.execution_id, offer_id:offer.id,
                binding:offer.binding, strategy_id:offer.strategy_id,
                vault_id:offer.vault_id, chain_id:offer.chain_id, taker:offer.taker,
                min_received_units:req.min_received_units.clone(),
                max_network_fee_wei:req.max_network_fee_wei.clone(),
                deadline:req.deadline.min(offer.expires_at),
            };
            Self::enqueue(&mut tx,"execution.egress.commands.v2",&offer.intent_id.to_string(),req.execution_id,
                Uuid::new_v5(&req.execution_id,b"egress.command"),serde_json::to_value(cmd)?).await?;
        }
        sqlx::query("INSERT INTO execution_authorizations(execution_id,offer_id,request_digest,response,accepted) VALUES($1,$2,$3,$4,$5)")
            .bind(req.execution_id).bind(req.offer_id).bind(digest)
            .bind(sqlx::types::Json(serde_json::to_value(&result)?)).bind(accepted)
            .execute(&mut *tx).await.context("inserting authorization")?;
        Self::enqueue(&mut tx,"execution.authorization.results.v2",&req.offer_id.to_string(),req.execution_id,
            Uuid::new_v5(&req.execution_id,b"authorization.result"),serde_json::to_value(&result)?).await?;
        tx.commit().await?;
        Ok(result)
    }
    pub async fn save_receipt(&self, r: &GasReceipt) -> Result<()> {
        ensure!(r.chain_id > 0 && r.gas_used > 0 && r.gas_used <= i64::MAX as u64, "bad gas receipt");
        ensure!(r.tx_hash.len()==66 && r.tx_hash.starts_with("0x") && r.tx_hash[2..].bytes().all(|c| c.is_ascii_hexdigit()), "bad tx hash");
        crate::swap::address(&r.contract)?;
        sqlx::query("INSERT INTO execution_gas_observations(chain_id,tx_hash,step_index,operation,contract,gas_used,succeeded) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING")
            .bind(r.chain_id as i64).bind(r.tx_hash.to_ascii_lowercase())
            .bind(r.step_index).bind(r.operation.as_str()).bind(r.contract.to_ascii_lowercase())
            .bind(r.gas_used as i64).bind(r.succeeded)
            .execute(&self.pool).await?;
        Ok(())
    }
}
