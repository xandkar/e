//! Narrow Aave-V3-compatible, same-chain, same-underlying native route.
//! Versions differ in gas evidence and simulation depth; they share this planner.
use crate::{model::*, interfaces::{FixedAavePlanner,NativePlan,Planner,Quoter}, provider::OfferProvider, rpc::Rpc, swap::{address, positive_uint256, sha256_hex, EvmCall}};
use anyhow::{bail, ensure, Context, Result};
use async_trait::async_trait;
use chrono::{Duration, Utc};
use num_bigint::BigUint;
use serde::{Deserialize, Serialize};
use std::{path::Path, sync::Arc};
use sqlx::PgPool;
use tokio::sync::Mutex;
use uuid::Uuid;

#[derive(Clone, Deserialize)]
pub struct NativePolicy {
    pub allowed_tokens: Vec<String>,
    pub allowed_pools: Vec<String>,
    pub withdraw_gas: u64,
    pub approve_gas: u64,
    pub supply_gas: u64,
    pub max_gas_per_step: u64,
    pub quote_ttl_seconds: i64,
}
impl NativePolicy {
    pub fn from_file(path: &Path) -> Result<Self> {
        let policy: Self = serde_json::from_slice(&std::fs::read(path)?)?;
        ensure!(!policy.allowed_tokens.is_empty() && !policy.allowed_pools.is_empty(), "native policy must include allowlisted contracts");
        ensure!(policy.max_gas_per_step >= 21_000 && policy.quote_ttl_seconds > 0 && policy.quote_ttl_seconds <= 120, "invalid gas/TTL policy");
        for addr in policy.allowed_tokens.iter().chain(&policy.allowed_pools) { address(addr)?; }
        Ok(policy)
    }
    fn permit(&self, i: &ReallocateIntent) -> Result<()> {
        let contains = |items: &[String], key: &str| items.iter().any(|it| it.eq_ignore_ascii_case(key));
        ensure!(contains(&self.allowed_tokens, &i.asset), "asset not allowlisted");
        ensure!(contains(&self.allowed_pools, &i.source_pool) && contains(&self.allowed_pools, &i.destination_pool), "pool not allowlisted");
        Ok(())
    }
    fn fallback(&self, op: Operation) -> u64 {
        match op { Operation::Withdraw => self.withdraw_gas, Operation::Approve => self.approve_gas, Operation::Supply => self.supply_gas }
    }
}

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct GasObservation {
    pub chain_id: u64,
    pub operation: Operation,
    pub contract: String,
    pub gas_used: u64,
    pub succeeded: bool,
}

pub fn gas_history(path: Option<&Path>) -> Result<Vec<GasObservation>> {
    match path { Some(path) => Ok(serde_json::from_slice(&std::fs::read(path)?)?), None => Ok(Vec::new()) }
}

// Nearest-rank percentiles and 30% margin, with fail-closed hard gas policy limit.
fn historical_estimate(samples: &[u64], fallback: u64, max_gas: u64) -> Result<(u64,u64,usize)> {
    ensure!(fallback > 0 && fallback <= max_gas, "fallback outside permitted gas bound");
    if samples.len() < 20 { return Ok((fallback, fallback, samples.len())); }
    let mut values = samples.to_vec();
    values.sort_unstable();
    let pct = |p: usize| -> u64 { values[(values.len()*p).div_ceil(100)-1] };
    let expected = pct(50);
    let p95 = pct(95);
    let limit = p95.checked_mul(130).and_then(|n| n.checked_add(99)).context("gas budget overflow")? / 100;
    ensure!(limit <= max_gas, "historical estimate exceeds gas policy");
    ensure!(limit >= expected, "limit lower than expected gas");
    Ok((expected, limit, values.len()))
}

fn abi_word_hex(amount: &BigUint) -> Result<String> {
    ensure!(amount.bits() <= 256, "uint256 overflow");
    let hex = amount.to_str_radix(16);
    ensure!(hex.len() <= 64, "uint256 overflow");
    Ok(format!("{:0>64}",hex))
}
fn abi_address(address_s: &str) -> Result<String> {
    let a = address(address_s)?;
    Ok(format!("{:0>64}", &a[2..]))
}

fn call_for(i: &ReallocateIntent, op: Operation, amount: &BigUint, gas: u64, gas_price: &BigUint) -> Result<EvmCall> {
    let (to, data) = match op {
        Operation::Withdraw => (i.source_pool.clone(), format!("0x69328dec{}{}{}", abi_address(&i.asset)?, abi_word_hex(amount)?,abi_address(&i.taker)?)),
        Operation::Approve => (i.asset.clone(), format!("0x095ea7b3{}{}", abi_address(&i.destination_pool)?, abi_word_hex(amount)?)),
        Operation::Supply => (i.destination_pool.clone(), format!("0x617ba037{}{}{}{}", abi_address(&i.asset)?, abi_word_hex(amount)?,abi_address(&i.taker)?,abi_word_hex(&BigUint::from(0u8))?)),
    };
    let call = EvmCall { to: address(&to)?, data, value_wei: "0".into(), estimated_gas: gas.to_string(), quoted_gas_price_wei: gas_price.to_string() };
    call.validate()?;
    Ok(call)
}

#[derive(Clone)]
pub struct NativeProvider {
    version: Version,
    policy: NativePolicy,
    history: Vec<GasObservation>,
    history_pool: Option<PgPool>,
    rpc: Option<Rpc>,
    fork_rpc: Option<Rpc>,
    // A single local fork cannot execute two mutable quote simulations concurrently.
    fork_lock: Arc<Mutex<()>>,
    fallback_gas_price_wei: BigUint,
}
impl NativeProvider {
    pub fn new(
        version: Version, policy: NativePolicy, history: Vec<GasObservation>,
        rpc: Option<Rpc>, fork_rpc: Option<Rpc>, fallback_gas_price_wei: &str,
    ) -> Result<Self> {
        ensure!(version != Version::V5, "native provider only supports v1-v4");
        let price = positive_uint256(fallback_gas_price_wei)?;
        if version == Version::V3 { ensure!(rpc.is_some(), "v3 requires --rpc-url"); }
        if version == Version::V4 { ensure!(fork_rpc.is_some(), "v4 requires --fork-rpc-url"); }
        Ok(Self { version, policy, history, history_pool: None, rpc, fork_rpc, fork_lock: Arc::new(Mutex::new(())), fallback_gas_price_wei: price })
    }
    pub fn with_history_pool(mut self, pool: PgPool) -> Self { self.history_pool = Some(pool); self }
    async fn recent(&self, i: &ReallocateIntent, op: Operation, contract: &str) -> Result<Vec<u64>> {
        if let Some(pool) = &self.history_pool {
            use sqlx::Row;
            let rows = sqlx::query("SELECT gas_used FROM execution_gas_observations WHERE chain_id=$1 AND operation=$2 AND contract=$3 AND succeeded AND observed_at >= now() - INTERVAL '30 days' ORDER BY observed_at DESC LIMIT 100")
                .bind(i.chain_id as i64).bind(op.as_str()).bind(address(contract)?)
                .fetch_all(pool).await?;
            return rows.into_iter().map(|r| { let n: i64 = r.try_get("gas_used")?; Ok(n as u64) }).collect();
        }
        Ok(self.history.iter().filter(|x| x.succeeded && x.chain_id == i.chain_id && x.operation == op && x.contract.eq_ignore_ascii_case(contract))
            .rev().take(100).map(|x| x.gas_used).collect())
    }
    fn contract(i: &ReallocateIntent, op: Operation) -> &str {
        match op { Operation::Withdraw => &i.source_pool, Operation::Approve => &i.asset, Operation::Supply => &i.destination_pool }
    }
    async fn build_quote(&self, i: &ReallocateIntent) -> Result<Offer> {
        i.validate()?;
        self.policy.permit(i)?;
        let steps = [Operation::Withdraw, Operation::Approve, Operation::Supply];
        let live_rpc = if self.version == Version::V4 { self.fork_rpc.as_ref() } else { self.rpc.as_ref() };
        if let Some(rpc) = live_rpc { ensure!(rpc.chain_id().await? == i.chain_id, "RPC network does not match intent.chain_id"); }
        let block_number = match live_rpc { Some(r) => Some(r.block_number().await?), None => None };
        let price = match live_rpc { Some(r) => r.gas_price().await?, None => self.fallback_gas_price_wei.clone() };
        ensure!(price > BigUint::from(0u8), "gas price must be positive");
        let amount = positive_uint256(&i.amount)?;
        let mut gas_estimates: Vec<(u64,u64)> = Vec::new();
        let mut evidence = Vec::new();
        let mut simulated_withdrawn: Option<BigUint> = None;

        if self.version == Version::V4 {
            // The caller MUST give a local Anvil fork, not the real chain. Snapshot is rolled back.
            let _exclusive = self.fork_lock.lock().await;
            let fork = self.fork_rpc.as_ref().context("missing fork")?;
            let snapshot = fork.fork_snapshot().await.context("v4 requires an Anvil snapshot-capable fork")?;
            let simulation: Result<()> = async {
                fork.impersonate(&i.taker).await?;
                for (index, op) in steps.iter().enumerate() {
                    let step_amount = if index == 0 { amount.clone() } else { simulated_withdrawn.clone().context("missing simulated withdrawal output")? };
                    let baseline = if *op == Operation::Withdraw { Some(fork.balance_of(&i.asset, &i.taker).await?) } else { None };
                    let historical = self.policy.fallback(*op);
                    let call = call_for(i, *op, &step_amount, historical, &price)?;
                    let (gas, _tx_hash) = fork.simulated_tx(&i.taker, &call.to, &call.data, self.policy.max_gas_per_step).await?;
                    if let Some(before) = baseline {
                        let after = fork.balance_of(&i.asset, &i.taker).await?;
                        ensure!(after >= before, "no positive withdrawal balance delta");
                        let received = after - &before;
                        ensure!(received > BigUint::from(0u8), "withdrawal produced no assets");
                        simulated_withdrawn = Some(received);
                    }
                    let limit = gas.checked_mul(130).and_then(|v| v.checked_add(99)).context("gas overflow")? / 100;
                    ensure!(limit <= self.policy.max_gas_per_step, "fork gas exceeds policy");
                    gas_estimates.push((gas, limit));
                    evidence.push(format!("{}: simulated on isolated Anvil fork; used {} gas", op.as_str(), gas));
                }
                // Verify the final supply actually consumed the simulated withdrawal.
                Ok(())
            }.await;
            // Stop impersonating even if a step failed. Roll back even on errors.
            let stop_impersonation = fork.stop_impersonate(&i.taker).await;
            let cleanup = fork.fork_revert(snapshot).await;
            if let Err(err) = cleanup { return Err(err.context("Anvil snapshot rollback failed")); }
            stop_impersonation.context("failed to stop fork account impersonation")?;
            simulation?;
        } else {
            for op in steps {
                let history = self.recent(i, op, Self::contract(i, op)).await?;
                let (mut expected, mut limit, count) = historical_estimate(&history, self.policy.fallback(op), self.policy.max_gas_per_step)?;
                let mut method = format!("{}: V2 history n={} (fallback when fewer than 20)", op.as_str(), count);
                if self.version == Version::V1 {
                    expected = self.policy.fallback(op);
                    limit = expected;
                    method = format!("{}: V1 configured gas budget", op.as_str());
                } else if self.version == Version::V3 && op != Operation::Supply {
                    // Withdraw and ERC20 approval can be simulated independently.
                    // Supply depends on previously withdrawn funds; retain history.
                    let rpc = self.rpc.as_ref().context("missing RPC")?;
                    let call = call_for(i, op, &amount, expected, &price)?;
                    let simulation = rpc.estimate(&i.taker, &call.to, &call.data, block_number.context("missing block number")?).await?;
                    expected = simulation;
                    limit = limit.max(simulation.checked_mul(120).context("gas overflow")? / 100);
                    method = format!("{}: RPC estimate at block {}", op.as_str(), block_number.unwrap_or(0));
                } else if self.version == Version::V3 && op == Operation::Supply {
                    method = "supply: dependent on withdrawal; historical fallback".into();
                }
                ensure!(limit >= expected && limit <= self.policy.max_gas_per_step, "unsafe gas limit");
                gas_estimates.push((expected,limit));
                evidence.push(method);
            }
        }
        let output = simulated_withdrawn.unwrap_or_else(|| amount.clone());
        // In this MVP, supported native tokens must be standard, non-fee-on-transfer
        // ERC20 assets. Supply receipt tokens and collateral health require Egress checks.
        let mut quote_steps = Vec::new();
        let mut expected_gas = 0u128;
        let mut max_gas = 0u128;
        for (index, op) in steps.iter().enumerate() {
            let (estimated, limit) = gas_estimates[index];
            expected_gas = expected_gas.checked_add(estimated as u128).context("gas sum overflow")?;
            max_gas = max_gas.checked_add(limit as u128).context("gas sum overflow")?;
            let dynamic = index > 0 && self.version == Version::V4;
            quote_steps.push(RecipeStep {
                operation: *op, contract: address(Self::contract(i,*op))?, token: address(&i.asset)?,
                amount: if dynamic { AmountRef::PriorOutput { step_index: 0 } } else { AmountRef::Fixed { units: output.to_string() } },
                estimated_gas: estimated,
                gas_limit: limit,
                estimated_call: Some(call_for(i,*op,&output,estimated,&price)?),
            });
        }
        let expected_fee = &price * BigUint::from(expected_gas);
        // Quotes require an executable hard cap greater than the expected fee.
        // Fee rates are volatile; Egress must apply live fee policies and reauthorize if needed.
        let max_fee = &price * BigUint::from(max_gas) * BigUint::from(2u8);
        let method = match self.version {
            Version::V1=>EstimateMethod::Static, Version::V2=>EstimateMethod::Historical,
            Version::V3=>EstimateMethod::RpcAndHistory, Version::V4=>EstimateMethod::StatefulFork,
            Version::V5=> unreachable!(),
        };
        evidence.push("Network fee budget = gas limits × current fee rate × 2; Egress must enforce current base fee/tip and maximum".into());
        evidence.push("Only approved standard same-asset Aave-style pool operations; protocol/account risk checked by Egress".into());
        if self.version == Version::V4 { evidence.push("Fork simulation uses one simulated block per auto-mined transaction; does not guarantee real multi-block ordering or slippage".into()); }
        let digest = sha256_hex(&serde_json::to_vec(&quote_steps)?);
        let plan_id = Uuid::new_v5(&i.id, b"direct-aave-style-v1");
        let now = Utc::now();
        let offer = Offer {
            id: Uuid::new_v4(), intent_id: i.id, strategy_id: i.strategy_id.clone(),
            vault_id: i.vault_id.clone(), version: self.version,
            provider: format!("native-{:?}", self.version).to_ascii_lowercase(),
            readiness: Readiness::Ready, chain_id: i.chain_id, taker: address(&i.taker)?,
            issued_at: now, expires_at: now + Duration::seconds(self.policy.quote_ttl_seconds),
            economics: Economics {
                output_token: address(&i.asset)?, expected_output_units: output.to_string(),
                minimum_output_units: output.to_string(),
                expected_network_fee_wei: expected_fee.to_string(), max_network_fee_wei: max_fee.to_string(),
                method, quote_block: block_number, assumptions: evidence,
                stress_tests: if self.version == Version::V4 { vec![StressTest {
                    scenario: "network_gas_price_2x".into(),
                    projected_network_fee_wei: (&expected_fee * BigUint::from(2u8)).to_string(),
                    notes: "Gas-price sensitivity only; not a replay of adverse pool-state changes".into(),
                }] } else { vec![] },
            },
            binding: Binding::NativeRecipe { plan_id, steps: quote_steps, recipe_digest: digest },
        };
        offer.validate()?;
        Ok(offer)
    }
}

#[async_trait]
impl Quoter for NativeProvider {
    async fn quote_plan(&self, intent: &Intent, plan: &NativePlan) -> Result<Offer> {
        let Intent::Reallocate(i) = intent else { bail!("native quoter supports reallocate only") };
        ensure!(plan.intent_id == i.id, "plan/intent mismatch");
        ensure!(plan.steps == vec![Operation::Withdraw,Operation::Approve,Operation::Supply], "unsupported native route");
        let offer = self.build_quote(i).await?;
        if let Binding::NativeRecipe { plan_id, .. } = &offer.binding {
            ensure!(*plan_id == plan.id, "planner/quoter disagreement");
        }
        Ok(offer)
    }
}

#[async_trait]
impl OfferProvider for NativeProvider {
    fn version(&self) -> Version { self.version }
    fn name(&self) -> &'static str { "native-aave-style" }
    async fn offers(&self, intent: &Intent) -> Result<Vec<Offer>> {
        let plans = FixedAavePlanner.plans(intent).await?;
        let mut results = Vec::new();
        for plan in &plans { results.push(self.quote_plan(intent,plan).await?); }
        Ok(results)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn historical_fallback_and_p95() {
        assert_eq!(historical_estimate(&[10,12],100,1000).unwrap(), (100,100,2));
        let v = vec![200u64; 100];
        assert_eq!(historical_estimate(&v,100,1000).unwrap(), (200,260,100));
    }
    #[test] fn abi_calldata() {
        let intent = ReallocateIntent { id:Uuid::nil(), strategy_id:"s".into(), vault_id:"2".into(), chain_id:1,
            taker:"0x1111111111111111111111111111111111111111".into(),
            asset:"0x2222222222222222222222222222222222222222".into(), amount:"1000000".into(),
            source_pool:"0x3333333333333333333333333333333333333333".into(),
            destination_pool:"0x4444444444444444444444444444444444444444".into() };
        let price=BigUint::from(1u8);
        let amount = positive_uint256(&intent.amount).unwrap();
        assert_eq!(call_for(&intent,Operation::Withdraw,&amount,300000,&price).unwrap().data.len(), 202);
        assert_eq!(call_for(&intent,Operation::Approve,&amount,75000,&price).unwrap().data.len(), 138);
        assert_eq!(call_for(&intent,Operation::Supply,&amount,300000,&price).unwrap().data.len(), 266);
    }
}
