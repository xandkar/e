use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use execution_v1_v5::{
    model::{QuoteRequest, Version, WireEnvelope}, native::{gas_history,NativePolicy,NativeProvider},
    provider::{OfferProvider,ZeroExAdapter}, rpc::{Rpc,safe_local_fork_url},
    service::ExecutionService, store::{GasReceipt,PgStore},
    zeroex::ZeroExProvider,
};
use rdkafka::{
    consumer::{CommitMode,Consumer,StreamConsumer}, message::Message,
    producer::{FutureProducer,FutureRecord}, util::Timeout, ClientConfig,
};
use serde_json::Value;
use sqlx::Row;
use std::{path::PathBuf,sync::Arc,time::Duration};
use tracing::{error,info,warn};
use uuid::Uuid;

#[derive(Parser, Debug)]
#[command(name="execution-v1-v5", version, about="Version-selectable DeFi quote engines with a common offer protocol")]
struct Cli {
    /// Select the implementation (v1-v4 native lending; v5 0x swaps).
    #[arg(long, global=true, value_enum, default_value_t=Version::V1)]
    engine: Version,

    /// Native pool/token allowlist and fallback gas policy.
    #[arg(long, global=true, default_value="examples/native_policy.json")]
    policy_file: PathBuf,
    /// Optional receipt observations fixture (CLI/offline testing).
    #[arg(long, global=true)]
    history_file: Option<PathBuf>,
    /// Ordinary EVM JSON-RPC, used by V1/V2 for live gas prices and V3 for simulation.
    #[arg(long, global=true, env="RPC_URL")]
    rpc_url: Option<String>,
    /// Local Anvil fork RPC. Absolutely never point this at a live remote chain.
    #[arg(long, global=true, env="ANVIL_FORK_RPC_URL")]
    fork_rpc_url: Option<String>,
    /// Gas-price fallback in wei when no RPC is supplied (illustrative, not live).
    #[arg(long, global=true, default_value="1000000000")]
    gas_price_wei: String,
    #[arg(long, global=true, env="ZEROX_API_KEY")]
    zeroex_api_key: Option<String>,
    #[arg(long, global=true, env="ZEROX_CHAIN_ID")]
    zeroex_chain_id: Option<u64>,
    #[arg(long, global=true, env="ZEROX_ALLOWANCE_HOLDER")]
    zeroex_allowance_holder: Option<String>,
    #[arg(long, global=true, env="DATABASE_URL")]
    database_url: Option<String>,
    #[arg(long, global=true, env="KAFKA_BROKERS", default_value="localhost:9092")]
    kafka_brokers: String,
    #[arg(long, global=true, default_value="execution.quote.requests.v2")]
    quote_topic: String,
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand, Debug)]
enum Command {
    /// Quote one request from a JSON file; no Kafka required.
    Quote { #[arg(long)] input: PathBuf },
    /// Consume Kafka requests, persist offers/authorizations in PostgreSQL, publish outbox.
    Serve,
    /// Ingest a *verified* completed transaction receipt into gas history.
    RecordGas { #[arg(long)] input: PathBuf },
}

async fn build_provider(cli: &Cli, pool: Option<sqlx::PgPool>) -> Result<Arc<dyn OfferProvider>> {
    if cli.engine == Version::V5 {
        let api_key = cli.zeroex_api_key.clone().context("V5 requires ZEROX_API_KEY")?;
        let chain_id = cli.zeroex_chain_id.context("V5 requires ZEROX_CHAIN_ID")?;
        let holder = cli.zeroex_allowance_holder.clone().context("V5 requires ZEROX_ALLOWANCE_HOLDER")?;
        return Ok(Arc::new(ZeroExAdapter { inner: ZeroExProvider::new(api_key,holder,chain_id)? }));
    }
    let policy = NativePolicy::from_file(&cli.policy_file)?;
    let history = gas_history(cli.history_file.as_deref())?;
    let rpc = cli.rpc_url.clone().map(Rpc::new).transpose()?;
    let fork_rpc = match cli.fork_rpc_url.clone() {
        Some(url) => { safe_local_fork_url(&url)?; Some(Rpc::new(url)?) }
        None => None,
    };
    let mut provider = NativeProvider::new(cli.engine,policy,history,rpc,fork_rpc,&cli.gas_price_wei)?;
    if let Some(pool) = pool { provider = provider.with_history_pool(pool); }
    Ok(Arc::new(provider))
}

fn consumer(brokers: &str, group: &str, topic: &str) -> Result<StreamConsumer> {
    let c: StreamConsumer = ClientConfig::new()
        .set("bootstrap.servers", brokers)
        .set("group.id", group)
        .set("enable.auto.commit", "false")
        .set("auto.offset.reset", "earliest")
        .create()?;
    c.subscribe(&[topic])?;
    Ok(c)
}
async fn read_quotes(brokers: String, topic: String, service: Arc<ExecutionService>) -> Result<()> {
    let group = format!("execution-{:?}-quotes",service.provider.version()).to_ascii_lowercase();
    let c = consumer(&brokers,&group,&topic)?;
    loop {
        let msg = c.recv().await?;
        let bytes = msg.payload().context("missing quote payload")?;
        let envelope: WireEnvelope<QuoteRequest> = serde_json::from_slice(bytes)?;
        anyhow::ensure!(envelope.version == 2, "unsupported envelope version");
        let result = service.quote(envelope.payload).await?;
        info!(request_id=%result.request_id, offers=result.offers.len(), "quote batch persisted");
        c.commit_message(&msg,CommitMode::Async)?;
    }
}
async fn read_authorizations(brokers: String, store: PgStore) -> Result<()> {
    let c = consumer(&brokers,"execution-versions-auth","execution.commands.v2")?;
    loop {
        let msg = c.recv().await?;
        let envelope: WireEnvelope<execution_v1_v5::model::ExecuteRequested> = serde_json::from_slice(msg.payload().context("missing authorization payload")?)?;
        anyhow::ensure!(envelope.version == 2, "unsupported envelope version");
        let response = store.authorize(&envelope.payload).await?;
        info!(?response,"authorization stored");
        c.commit_message(&msg, CommitMode::Async)?;
    }
}
async fn publish_outbox(brokers: String, store: PgStore) -> Result<()> {
    let producer: FutureProducer = ClientConfig::new()
        .set("bootstrap.servers",brokers).set("message.timeout.ms","10000").create()?;
    loop {
        let mut tx=store.pool.begin().await?;
        let row=sqlx::query("SELECT event_id,topic,event_key,payload FROM execution_outbox WHERE sent_at IS NULL ORDER BY created_at LIMIT 1 FOR UPDATE SKIP LOCKED")
            .fetch_optional(&mut *tx).await?;
        let Some(row)=row else { tx.commit().await?; tokio::time::sleep(Duration::from_millis(250)).await; continue };
        let id:Uuid=row.try_get("event_id")?;
        let topic:String=row.try_get("topic")?;
        let key:String=row.try_get("event_key")?;
        let data:sqlx::types::Json<Value>=row.try_get("payload")?;
        let encoded=serde_json::to_string(&data.0)?;
        match producer.send(FutureRecord::to(&topic).payload(&encoded).key(&key),Timeout::After(Duration::from_secs(10))).await {
            Ok(_) => {
                sqlx::query("UPDATE execution_outbox SET sent_at=now() WHERE event_id=$1").bind(id).execute(&mut *tx).await?;
                tx.commit().await?;
            }
            Err((err,_)) => {
                error!(%err,event_id=%id,"Kafka publish failed; retrying pending event");
                tx.rollback().await?;
                tokio::time::sleep(Duration::from_secs(1)).await;
            }
        }
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt().with_env_filter(
        tracing_subscriber::EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into())
    ).init();
    let cli = Cli::parse();
    match &cli.command {
        Command::Quote {input} => {
            let request:QuoteRequest=serde_json::from_slice(&std::fs::read(input)?)?;
            // Optional DB makes V2 capable of using observations already collected in production.
            let pool=match &cli.database_url {
                Some(url)=>Some(PgStore::connect(url).await?.pool),
                None=>None,
            };
            let provider=build_provider(&cli,pool).await?;
            let svc=ExecutionService{provider,store:None};
            println!("{}",serde_json::to_string_pretty(&svc.quote(request).await?)?);
        }
        Command::RecordGas {input} => {
            let url=cli.database_url.as_deref().context("DATABASE_URL is required for record-gas")?;
            let store=PgStore::connect(url).await?;
            let item:GasReceipt=serde_json::from_slice(&std::fs::read(input)?)?;
            store.save_receipt(&item).await?;
            println!("saved or deduplicated verified gas observation");
        }
        Command::Serve => {
            let url=cli.database_url.as_deref().context("DATABASE_URL is required for serve")?;
            let store=PgStore::connect(url).await?;
            let provider=build_provider(&cli,Some(store.pool.clone())).await?;
            let svc=Arc::new(ExecutionService{provider,store:Some(store.clone())});
            warn!(engine=?cli.engine,"Execution commands are NOT Fireblocks submissions; Egress must revalidate and settle them");
            // Deploy one authorization worker per environment, not one per engine.
            tokio::try_join!(
                read_quotes(cli.kafka_brokers.clone(),cli.quote_topic.clone(),svc),
                read_authorizations(cli.kafka_brokers.clone(),store.clone()),
                publish_outbox(cli.kafka_brokers.clone(),store),
            )?;
        }
    }
    Ok(())
}
