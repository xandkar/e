//! Minimal JSON-RPC client. V4 MUST only point to an isolated, local Anvil fork.
use anyhow::{bail, ensure, Context, Result};
use num_bigint::BigUint;
use serde_json::{json, Value};
use std::{sync::{Arc, atomic::{AtomicU64,Ordering}}, time::Duration};
use crate::swap::address;

#[derive(Clone)]
pub struct Rpc {
    http: reqwest::Client,
    url: String,
    id: Arc<AtomicU64>,
}
impl Rpc {
    pub fn new(url: String) -> Result<Self> {
        ensure!(url.starts_with("http://") || url.starts_with("https://"), "invalid RPC URL");
        Ok(Self { http: reqwest::Client::builder().timeout(Duration::from_secs(30)).build()?, url, id: Arc::new(AtomicU64::new(0)) })
    }
    pub async fn call(&self, method: &str, params: Value) -> Result<Value> {
        let id = self.id.fetch_add(1, Ordering::Relaxed);
        let response = self.http.post(&self.url).json(&json!({"jsonrpc":"2.0", "id":id, "method":method,"params":params}))
            .send().await.context("RPC transport")?.error_for_status().context("RPC HTTP status")?;
        let doc: Value = response.json().await.context("RPC JSON")?;
        if let Some(error) = doc.get("error") { bail!("{method}: RPC error: {error}"); }
        doc.get("result").cloned().context("missing RPC result")
    }
    pub async fn chain_id(&self) -> Result<u64> { hex_u64(&self.call("eth_chainId", json!([])).await?) }
    pub async fn block_number(&self) -> Result<u64> { hex_u64(&self.call("eth_blockNumber", json!([])).await?) }
    pub async fn gas_price(&self) -> Result<BigUint> { hex_big(&self.call("eth_gasPrice", json!([])).await?) }
    pub async fn balance_of(&self, token: &str, wallet: &str) -> Result<BigUint> {
        let token = address(token)?;
        let wallet = address(wallet)?;
        let input = format!("0x70a08231{:0>64}", &wallet[2..]);
        let raw = self.call("eth_call", json!([{"to":token,"data":input},"latest"])).await?;
        hex_big(&raw)
    }
    pub async fn estimate(&self, from: &str, to: &str, data: &str, block: u64) -> Result<u64> {
        let raw = self.call("eth_estimateGas", json!([{"from":from,"to":to,"data":data,"value":"0x0"}, format!("0x{block:x}")])).await?;
        hex_u64(&raw)
    }
    pub async fn fork_snapshot(&self) -> Result<Value> { self.call("evm_snapshot", json!([])).await }
    pub async fn fork_revert(&self, snapshot: Value) -> Result<()> {
        ensure!(self.call("evm_revert", json!([snapshot])).await? == json!(true), "snapshot rollback unsuccessful");
        Ok(())
    }
    pub async fn impersonate(&self, wallet: &str) -> Result<()> {
        self.call("anvil_impersonateAccount", json!([address(wallet)?])).await?; Ok(())
    }
    pub async fn stop_impersonate(&self, wallet: &str) -> Result<()> {
        self.call("anvil_stopImpersonatingAccount", json!([address(wallet)?])).await?; Ok(())
    }
    pub async fn simulated_tx(&self, from: &str, to: &str, data: &str, gas: u64) -> Result<(u64, String)> {
        let hash = self.call("eth_sendTransaction", json!([{
            "from": address(from)?, "to":address(to)?, "data":data,
            "value":"0x0", "gas": format!("0x{gas:x}")
        }])).await?.as_str().context("missing simulated tx hash")?.to_string();
        // Anvil default automining is instantaneous. Bounded polling handles slower configurations.
        for _ in 0..30 {
            let receipt = self.call("eth_getTransactionReceipt", json!([&hash])).await?;
            if !receipt.is_null() {
                ensure!(receipt.get("status").and_then(Value::as_str) == Some("0x1"), "fork transaction reverted");
                let gas = hex_u64(receipt.get("gasUsed").context("missing gasUsed")?)?;
                return Ok((gas, hash));
            }
            tokio::time::sleep(Duration::from_millis(100)).await;
        }
        bail!("fork transaction receipt timed out")
    }
}

pub fn hex_big(value: &Value) -> Result<BigUint> {
    let s = value.as_str().context("expected hex string")?;
    ensure!(s.starts_with("0x"), "non-hex RPC value");
    let digits = &s[2..];
    if digits.is_empty() { return Ok(BigUint::from(0u8)); }
    ensure!(digits.bytes().all(|b| b.is_ascii_hexdigit()), "malformed hex");
    let value = BigUint::parse_bytes(digits.as_bytes(), 16).context("invalid hex integer")?;
    ensure!(value.bits() <= 256, "uint256 overflow");
    Ok(value)
}
pub fn hex_u64(value: &Value) -> Result<u64> {
    let n = hex_big(value)?;
    n.to_string().parse::<u64>().context("u64 overflow")
}

pub fn safe_local_fork_url(url: &str) -> Result<()> {
    // Prevent eth_sendTransaction from ever targeting a remote/public RPC.
    // For remote Anvil use SSH tunneling to loopback, not --fork-rpc to remote.
    let allowed = ["http://127.0.0.1:", "http://localhost:", "http://[::1]:"];
    ensure!(allowed.iter().any(|p| url.starts_with(p)), "V4 fork RPC must be a local HTTP Anvil node");
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn fork_rejects_remote_url() {
        assert!(safe_local_fork_url("https://mainnet.infura.io/v3/key").is_err());
        assert!(safe_local_fork_url("http://127.0.0.1:8545").is_ok());
    }
    #[test] fn hex_parse() { assert_eq!(hex_u64(&json!("0x7b")).unwrap(), 123); }
}
